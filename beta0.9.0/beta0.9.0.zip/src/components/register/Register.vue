<template>
  <div class="register">
    <group class="loginTop" title="登录信息">
    	<!--
      <org-selector v-model="orgs" label="单位名称" :maxLength="1"></org-selector>
    	-->
      <!--<x-input title="用户科室:"  v-model='dataUser.department' :show-clear="false"></x-input>-->
      <x-input title="用户登录名:"  placeholder="必填"   v-model='dataUser.userLoginname' :show-clear="false"></x-input>
      <x-input title="用户密码:"  placeholder="*8-16位,必须含字母和数字" v-model='dataUser.userPwd' :show-clear="false"></x-input>

    </group>
    <group class="loginTel" title="个人信息">

        <org-check-list class="unitName" v-model="orgs" label="单位名称" :maxLength="1"></org-check-list>
        <x-input title="用户姓名:" placeholder="必填" v-model='dataUser.userName' :show-clear="false"></x-input>
      <!--<popup-radio title="用户性别" :options="options" v-model="dataUser.sex"></popup-radio>-->
        <x-input title="用户职务:"  placeholder="必填"   v-model='dataUser.userProf' :show-clear="false"></x-input>
        <x-input title="手机号码:"  placeholder="必填" v-model='dataUser.userCellPhone' :show-clear="false" keyboard="number" is-type="china-mobile"></x-input>
        <x-input title="办公电话:"  placeholder="必填" v-model='dataUser.userTel' :show-clear="false" keyboard="number" ></x-input>
        <x-input title="邮箱:" v-model='dataUser.uesrEmail' :show-clear="false" is-type="email"></x-input>
        <x-input title="QQ:" v-model='dataUser.userQq' :show-clear="false" keyboard="number" ></x-input>
        <!--<x-input title="微信号:" v-model='dataUser.userWechat' :show-clear="false"></x-input>-->
    </group>
    <box gap="10px 10px">
      <x-button type="theme" @click.native="register">提交申请</x-button>
    </box>
    <divider>Copyright &copy; 武汉市应急办</divider>
  </div>
</template>

<style lang="less" scoped>
  .unitName {

  }
  .loginTop .weui-cells__title + .weui-cells {
  }
  .loginTel .weui-cells__title + .weui-cells {
    height: 230px;
    margin-bottom: 40px;
  }
  .loginTel .weui-label {
    text-align: right;
  }
 .weui-cells:before {
    display: none;
  }
</style>
<script>
  import {
    PopupRadio,
    XInput,
    Group,
    XButton,
    Box,
    Divider
    } from 'vux'
  import { siteUrl } from '../../utils/common'
  import OrgSelector from '../gsafetycomponents/OrgSelector.vue'
  import OrgCheckList from '../inforeport/commoncompents/OrgCheckList'

  export default {
      // 数据模型
    data() {
      return {
        submitStatus: false,
        dataUser: {
          sex: '0'
        },
        message: '',
        orgs: [],
        options: [{ key: '0', value: '男' }, { key: '1', value: '女' }]
      }
    },
    // 组件
    components: {
      PopupRadio,
      XInput,
      Group,
      XButton,
      OrgSelector,
      OrgCheckList,
      Box,
      Divider
    },
    beforeRouteEnter(to, from, next) {
      next((vm) => {
        // 通过 `vm` 访问组件实例
        vm.$store.commit('setHeaderTitle', '注册申请') // 设置头部文字
      })
    },
    // vue实例创建后调用
    created() {
    },
    // 定义方法区
    methods: {
      register() {
        const that = this
        this.dataUser.userOrgCode = this.convertUser(this.orgs)
        const data = that.dataUser
        this.submitStatus = this.validation(data)
        const URL = `${siteUrl}/basregisterlist/add?registerChannel=APP`
        if (this.submitStatus) {
          this.$vux.confirm.show({
            title: '确认申请？',
            content: '',
            onConfirm() {
              that.$http.post(URL, data).then((response) => {
                // console.log(response)
                if (response.body.code === 200) {
                  that.$gsafety.closeWindow(response.body.code)
                  that.$vux.toast.text('申请成功！', 'middle')
                  // alert('申请成功！')
                  that.$vux.confirm.hide()
                } else if (response.body.message) {
                  that.message = response.body.message
                  alert(that.message)
                }
              }, () => {
                // alert('操作失败')
                that.$vux.toast.text('操作失败', 'middle')
                that.$vux.confirm.hide()
              })
            }
          })
        }
      },
      convertUser(val) {
        return val[0]
      },
      validation(data) {
        if (!data.userOrgCode) {
          alert('单位尚未选择，请选择！')
          return false
        }
        const regex = '^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{8,16}$'
        const reg = new RegExp(regex)
        if (!reg.test(data.userPwd)) {
          if (data.userPwd.length < 8 || data.userPwd.length > 16) {
            alert('用户密码输入不正确，必须为8-16位！')
          } else {
            alert('用户密码输入不正确，必须为英文和数字的组合！')
          }
          return false
        }
        return true
      }
    }
  }
</script>
