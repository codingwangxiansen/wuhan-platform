<template>
  <div class="error">
    <!--报错页面-->
    <img src="../../assets/image/404.png" alt="">
  </div>
</template>
<script>
</script>
<style lang="less" scoped>
  .error {
    text-align: center;
  }
</style>
