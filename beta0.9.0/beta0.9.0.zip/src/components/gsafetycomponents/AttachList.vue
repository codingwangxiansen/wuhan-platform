
<template>
  <group  v-if="attachs.length">
    <div class="file-part">
      <div class="attach-title"><img src="../../assets/image/icon/file-icon.png">附件</div>
      <cell :title="attach.name | stringFilter"  v-for="(attach,index) in myAttachs" :key="index"  @click.native="openAttach(attach)" is-link>
        <div class="icon-part" slot="icon"><img :src="attach.imgSrc"/></div>
      </cell>
    </div>
  </group>
</template>
<style>
  .file-part{
    padding: 0 15px;
    background: #ffffff;
    line-height: 46px;
  }

  .file-part .weui_cell{
    padding: 10px 0;
  }

  .file-part .attach-title{
    font-size: 16px;
  }

  .file-part .attach-title img{
    width: 20px;
    margin-right: 5px;
    vertical-align: middle;
  }

  .file-part .icon-part img{
    width: 20px;
    margin-top: 17px;
    margin-right: 5px;
  }

  .file-part .weui_cell_bd > p{
    color: #999999;
  }

  .file-part .vux-label-desc{
    padding: 0;
  }


</style>
<script>
  import Vue from 'vue'
  import VueResource from 'vue-resource'
  import { XButton, Group, Cell } from 'vux'
  import { $gsafety, pathConfig } from '../../utils/common'

  Vue.use(VueResource)

  export default{
    name: 'AttachModel',
    props: ['attachs'],
    data() {
      return {
        noAttach: false,
        isAttach: true
      }
    },
    components: {
      XButton, Group, Cell
    },
    computed: {
      myAttachs() {
        const tAttachs = this.attachs
        tAttachs.forEach((attachItem) => {
          const index = attachItem.name.lastIndexOf('.')
          const length = attachItem.name.length
          const suffix = attachItem.name.substring(index + 1, length)
          let imgSrc
          if (suffix === 'doc' || suffix === 'docx') {
            imgSrc = '../static/image/dynamic-icon/word-icon.png'
          } else if (suffix === 'txt') {
            imgSrc = '../static/image/dynamic-icon/txt-icon.png'
          } else if (suffix === 'xls' || suffix === 'xlsx') {
            imgSrc = '../static/image/dynamic-icon/xls-icon.png'
          }
          console.log(imgSrc)
          Vue.set(attachItem, 'imgSrc', imgSrc)
        })
        return tAttachs
      }
    },
    created() {
    },
    methods: {
      openAttach(attach) {
        const p = `${location.origin}${pathConfig.ATTACH_VIEW}#/${attach.id}`
        const openWindowOptions = { url: p, showActionBar: false }
        if ($gsafety) {
          $gsafety.openWindow(openWindowOptions)
        }
      }
    },
    filters: {
      stringFilter(string) {
        let changeStr
        if (string.length > 18) {
          changeStr = `${string.substring(0, 15)}...`
        }
        return changeStr
      }
    }
  }
</script>
