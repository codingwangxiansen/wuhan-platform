<template>
  <div>
    <group title="常用功能">
      <cell title="修改密码" link="/user/pass" is-link></cell>
      <cell title="消息中心" link="/push" is-link></cell>
      <!--
      <x-button type="theme" @click.native="changePass">修改密码</x-button>
      <x-button type="default" @click.native="message">消息中心</x-button>
      -->
      <!--<x-button type="primary" @click.native="open(createUrl)" v-show="canReply">反馈</x-button>-->
    </group>
  </div>
</template>
<style lang="less" scoped>
  @import "../../styles/common.less";
 .transInfo {
   margin-top: 2em;
 }
</style>
<script>
  import {
      XButton,
      Group,
      Box,
      Cell
  } from 'vux'
  import Vue from 'vue'
  import VueResource from 'vue-resource'

  Vue.use(VueResource)

  export default {
    // 组件
    components: {
      XButton,
      Group,
      Box,
      Cell
    },
    // 数据模型
    data() {
      return {
        check: '',
        currentUser: {}
      }
    },
    created() {
      this.$store.commit('setHeaderTitle', '设置') // 设置头部文字
      this.currentUser = this.$store.state.user
    },
    computed: {
      showTransAdmin() {
        if (this.$store.state.user.auditStatus === '1') {
          return true
        }
        return false
      }
    },
    // 方法
    methods: {
      userCheck() {
        const r = '/user/usercheck'
        this.$router.push(r)
      },
      changePass() {
        const r = '/user/pass'
        this.$router.push(r)
      },
      adTransfer() {
        const r = '/user/adreview'
        this.$router.push(r)
      },
      message() {
        const r = '/push'
        this.$router.push(r)
      }
    }
  }
</script>
