<template>
  <div>
    <ul class="img-box clearfix weui_uploader_bd weui_uploader_files">
      <li class="weui_uploader_file" v-show="canUpload">
        <!--gs-add_a_video-->
        <div class="gs-settings_voice" @click="chooseAudio">
        </div>
      </li>
      <li v-for="(audio,index) in audios " class="weui_uploader_file">
        <div class="video-content">
          <div class="video-icon" @click="playAudio(audio)">
            <i class="gs-volume-high"></i>
          </div>
        </div>
        <a v-show="delet" @click="deleteAudio(index)" class="deleteImg">
          <img src="../../assets/image/weixin/eventInfo/delete_img.png" />
        </a>
      </li>
    </ul>
  </div>
</template>
<!---->
<style lang="less" scoped>
  @import '../../styles/weui-upload.less';
  .weui_uploader_file .deleteImg {
    top: 5px;
  }
  .gs-volume-high {
    font-size: 48px;
  }
  div.gs-settings_voice {
    width: 70px;
    height: 70px;
    border: 1px solid #e8e8e8;
    position: relative;
  }
  div.gs-settings_voice:before {
    font-size: 3em;
    position: absolute;
    color: #8e8e8e;
    top: 0px;
    left: 9px;
  }
  div.gs-settings_voice::after {
    content: '上传语音';
    color: #8e8e8e;
    position: absolute;
    font-size: 0.7em;
    left: 1em;
    bottom: 0.3em;
  }
  .video-content{
    height: 100%;
    padding-top: 18px;
    box-sizing: border-box;
  }

  .video-icon{
    width: 44px;
    height: 44px;
    text-align: center;
    font-size: 24px;
    background: #FFFFFF;
    color: #8f9196;
    margin: auto;
    border-radius: 32px;
    line-height: 46px;
  }
</style>
<script>
  /**
   * 视频上传组件
   */

  export default {
    name: 'AudioUpload',
    props: {
      audios: {
        type: Array,
        default() {
          return []
        }
      },
      audioMaxSum: { // 最多视频数量
        type: String,
        default() {
          return '3'
        }
      },
      canUpload: { // 控制上否能上传语音
        type: Boolean,
        default: true
      },
      delet: {
        type: Boolean,
        default: true
      }
    },
    computed: {
    },
    created() {

    },
    methods: {
      chooseAudio() {
        if (this.audios.length < parseInt(this.audioMaxSum, 10)) {
          this.$emit('on-choose')
        } else {
          alert(`最多只能上传${this.audioMaxSum}条语音`)
        }
      },
      playAudio(audio) {
        const audioObj = {
          id: audio.id,
          path: audio.attachPath
        }
        this.$gsafety.playVoice(audioObj)
      },
      deleteAudio(index) {
        this.$emit('on-delete', index)
      }
    }
  }
</script>

