<template>
  <div>
    <ul class="img-box clearfix weui_uploader_bd weui_uploader_files">
      <li class="weui_uploader_file" v-show="canUpload">
        <!--gs-add_a_video-->
        <div class="gs-video_call" @click="chooseVideo">
        </div>
      </li>
      <li v-for="(video,index) in videos " class="weui_uploader_file">
        <div class="video-content">
          <div class="video-icon" @click="playVideo(video)">
            <i class="gs-play_arrow"></i>
          </div>
        </div>
        <a v-show="delet" @click="deleteVideo(index)" class="deleteImg">
          <img src="../../assets/image/weixin/eventInfo/delete_img.png" />
        </a>
      </li>
    </ul>
  </div>
</template>
<!---->
<style lang="less" scoped>
  @import '../../styles/weui-upload.less';
  .weui_uploader_file .deleteImg {
    right: -5px;
  }
  .gs-play_arrow {
    font-size: 60px;
    border: 1px solid #ddd;
    border-radius: 33%;
    background: #8f9196;
    color: #fff;
  }
  div.gs-video_call {
    width: 70px;
    height: 70px;
    border: 1px solid #e8e8e8;
    position: relative;
  }
  div.gs-video_call:before {
    font-size: 3em;
    position: absolute;
    color: #8e8e8e;
    top: 5px;
    left: 11px;
  }
  div.gs-video_call::after {
    content: '上传视频';
    color: #8e8e8e;
    position: absolute;
    font-size: 0.7em;
    left: 1em;
    bottom: 0.5em;
  }
  .video-content{
    height: 100%;
    padding-top: 10px;
    box-sizing: border-box;
  }

  .video-icon{
    width: 44px;
    height: 44px;
    text-align: center;
    font-size: 24px;
    background: #FFFFFF;
    color: #5f909e;
    margin: auto;
    border-radius: 32px;
    line-height: 46px;
  }
</style>
<script>
  /**
   * 视频上传组件
   */

  export default {
    name: 'VideoUpload',
    props: {
      videos: {
        type: Array,
        default() {
          return []
        }
      },
      videoMaxSum: {  // 最多视频数量
        type: String,
        default() {
          return '3'
        }
      },
      canUpload: { // 控制上否能上传视频
        type: Boolean,
        default: true
      },
      delet: {
        type: Boolean,
        default: true
      }
    },
    computed: {
    },
    created() {

    },
    methods: {
      chooseVideo() {
        if (this.videos.length < parseInt(this.videoMaxSum, 10)) {
          this.$emit('on-choose')
        } else {
          alert(`最多只能上传${this.videoMaxSum}个视频`)
        }
      },
      playVideo(video) {
        const videoObj = {
          id: video.id,
          path: video.attachPath
        }
        this.$gsafety.playVideo(videoObj)
      },
      deleteVideo(index) {
        this.$emit('on-delete', index)
      }
    }
  }
</script>

