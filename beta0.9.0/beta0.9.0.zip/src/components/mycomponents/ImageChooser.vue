<template>
  <img-upload
    :localIds="localIds"
    :serverIds="serverIds"
    :imgMaxSum="imgMaxSum"
    @on-choose="chooseImg"
    @on-delete="deleteImg">
  </img-upload>
</template>
<!---->
<style lang="less" scoped>

</style>
<script>
  import ImgUpload from './ImgUpload'
  /**
   * 微信图片上传组件
   */
  export default {
    name: 'ImageChooser',
    components: {
      ImgUpload
    },
    data() {
      return {
        localIds: [],
        serverIds: [],
        imgMaxSum: '9'
      }
    },
    created() {

    },
    methods: {
      chooseImg() {  // 上传图片点击上传
        const vm = this
        const options = {}
        this.$gsafety.chooseImage(options, (res) => {
          if (res) {
            vm.localIds.push(res.url)
            const localImgId = res.url
            let imgSrc
            if (localImgId.indexOf('storage') > -1) {
              const start = localImgId.indexOf('storage')
              imgSrc = localImgId.substring(start + 7, localImgId.length)
            } else {
              imgSrc = localImgId
            }
            const jsonObj = { localId: imgSrc }
            this.$gsafety.uploadImage(jsonObj, (ress) => {
              if (ress.id) {
                vm.$vux.toast.text('图片上传成功', 'middle')
                vm.serverIds.push(ress.id)
                this.$emit('image-upload', vm.serverIds)
                // vm.alertShow('图片上传成功')
              } else {
                vm.$vux.toast.text('上传图片失败', 'middle')
                // vm.alertShow('上传图片失败')
              }
            })
          }
        })
      },
      deleteImg(index) { // 删除图片自定义回调事件
        this.localIds.splice(index, 1)
        this.serverIds.splice(index, 1)
        this.$emit('image-upload', this.serverIds)
      }
    }
  }
</script>

