<template>
  <div>
    <ul class="img-box clearfix weui_uploader_bd weui_uploader_files">
      <li class="weui_uploader_file">
        <!--gs-add_a_photo-->
        <div class="gs-add_a_photo" @click="chooseImg">
        </div>
      </li>
      <li v-for="(localId,index) in localIds " class="weui_uploader_file">
      <img :src="localId">
      <a @click="deleteImg(index)" class="deleteImg"><img src="../../assets/image/weixin/eventInfo/delete_img.png" /></a>
    </li>
    </ul>
  </div>
</template>
<!---->
<style lang="less" scoped>
  @import '../../styles/weui-upload.less';
  div.gs-add_a_photo {
    width: 70px;
    height: 70px;
    border: 1px solid #e8e8e8;
    position: relative;

  }
  div.gs-add_a_photo:before {
    font-size: 3em;
    position: absolute;
    color: #8e8e8e;
    top: 2px;
    left: 9px;
  }
  div.gs-add_a_photo::after {
    content: '\4E0A\4F20\56FE\7247';
    color: #8e8e8e;
    position: absolute;
    font-size: 0.7em;
    left: 1em;
    bottom: 0.5em;
  }
</style>
<script>
  /**
   * 微信图片上传组件
   */
  export default {
    name: 'ImgUpload',
    props: {
      localIds: {
        type: Array,
        default() {
          return []
        }
      },
      serverIds: {
        type: Array,
        default() {
          return []
        }
      },
      imgMaxSum: {
        type: String,
        default() {
          return '9'
        }
      }
    },
    created() {

    },
    methods: {
      chooseImg() {
        if (this.localIds.length < parseInt(this.imgMaxSum, 10)) {
          this.$emit('on-choose')
        } else {
          alert(`最多只能上传${this.imgMaxSum}张图片`)
        }
      },
      deleteImg(e, index) {
        this.$emit('on-delete', e, index)
      }
    }
  }
</script>

