<template>
  <div>

  </div>
</template>

<style lang="less" scoped>

</style>
<script>
  export default {
    // 数据模型
    data() {
      return {
      }
    },
    // 组件
    components: {
    },
    // vue实例挂着后调用
    mounted() {
    },
    watch: {
    },
    // 定义方法区
    methods: {
    }
  }
</script>
