<template>
<div class="cellBox">
	<!-- 这一块固定在顶部 -->
	<div>
		<!-- 搜索框 -->
		<!--
		<search placeholder="搜索机构"  v-model="filterInput" autoFixed
	    	cancel-text="清空" @on-change="query">
	    </search>
		-->
	    <!-- 树节点路由 -->
		<check-native	@on-root-click="goRoot" @on-node-click="goNode"
			 :route="nodeRoute">
		</check-native>
		<!-- 机构显示清单列表 -->
    <div align="left" class="checkedDiv"><span v-for="(one, index) in currentValue" class="checkedOrg"    @click="clearOrg(one)"> {{one.name}} </span></div>
  </div>
	<!-- 机构列表 -->
	<div class="weui-cells weui-cells_checkbox">
		<div v-for="(one, index) in list" class="containerBox">
		    <label class="weui-cell weui-check__label">
		        <div class="weui-cell__hd" >
		            <input type="checkbox" class="weui-check" v-model="currentValue" :value="one" @change="onOrgChange(one)">
		            <i class="weui-icon-checked" ></i>
		        </div>
		        <div class="weui-cell__bd">
		            <p>{{one.name}}</p>
		        </div>
		    </label>
		    <p @click.stop="expendNode(one)" v-show="one.childNum > 0" class="coll org-child-btn">></p>
		</div>
	</div>
	<!-- 确定按钮 固定在底部 -->
	<box class="gaBtn" gap="10px 10px">
		<x-button type="theme" @click.native="confirm">确定</x-button>
	</box>
</div>
</template>
<style lang="less" scoped>

.weui-cells {
	margin-bottom:0px;
	height:70%;
	overflow:scroll;
}
.gaBtn {
	position:fixed;
	bottom:0;
	width:95%;
}
.cellBox {
	height:100%;
	position:relative;
}
 .containerBox {
 	position:relative;
 }
 .coll {
 	position:absolute;
 	right:13px;
 	top:20%
 }
 .checkedDiv{
    padding: 0 1rem;
 }
 .checkedOrg{
    color: #fff;
    background-color: #67c23a;
    border-radius: 0.3rem;
    padding:0.2rem;
    display: inline-block;
    margin: 0.1rem;
 }
 .org-child-btn{
 	color: #909399;
    font-size: 1.5rem;
    padding: 0.2rem 1.5rem;;
    right: 0.2rem;
 }
</style>
<script>
  import { XButton, Box, Search } from 'vux'
  import CheckNative from './CheckNative'
  import { siteUrl } from '../../../utils/common'

  export default {
    name: 'CheckCell',
    props: ['value', 'maxLength'],
    data() {
      return {
        root: { name: '', value: '-1' },
        nodeRoute: {
          history: [],
          current: { name: '', value: '-1' }
        },
        filterInput: '',
        list: []
      }
    },
    computed: {
      currentValue: {
        get() {
          return this.value
        },
        set(val) {
          this.$emit('input', val)
        }
      }
    },
    components: {
      CheckNative,
      XButton,
      Box,
      Search
    },
    mounted() {
      this.goRoot()
    },
    methods: {
    // 点击当前节点
      expendNode(one) {
        // 添加当前节点到历史，并指向新的节点
        this.nodeRoute.history.push(this.nodeRoute.current)
        this.nodeRoute.current = one

        // 加载新节点列表
        this.pullNodes()
      },
      onOrgChange(one) {
        if (this.maxLength > 1) {
          return
        }

        const l = []
        l.push(one)
        this.currentValue = l
      },
      // 切换到根节点
      goRoot() {
        // 清空路由信息
        this.nodeRoute.history = []
        this.nodeRoute.current = this.root

        // 刷新页面
        this.pullNodes()
      },
      // 切换到指定节点
      goNode(item) {
        // 获取栈顶节点
        const t = this.nodeRoute.history.pop()
        if (t === item) {
          // 如果与点击节点一致，结束并拉取数据
          this.nodeRoute.current = t
          this.pullNodes()
        } else {
          // 否则继续返回
          this.goNode(item)
        }
      },
      clearOrg(one) {
        this.currentValue.shift(one)
      },
      // 从服务端拉取列表
      pullNodes() {
        const parentid = this.nodeRoute.current.value
        const url = `${siteUrl}/basedata/org/mobileOrgList?orgCode=${parentid}`
        const vm = this
        this.$http.get(url).then((res) => {
          vm.list = []
          const array = res.body.response
          if (array) {
            const itemArr = Object.values(array)
            itemArr.forEach((value) => {
              const record = {
                name: value.orgName,
                value: value.orgCode,
                childNum: value.isLeaf,
                inlineDesc: ''
              }
              vm.list.push(record)
            })
          }
        })
      },
      // 确定提交消息
      confirm() {
        this.goRoot()
        this.$emit('on-org-select', this.currentValue)
      },
       //
      query() {
        console.log('query tree')
      }
    }
  }
</script>
