<!-- 转办控件	 -->
<template>
  <div class="transList">
    <group title="转办督办" class="deal gs-tune">
      <i class="icon" @click.prevent="transShow = !transShow" :class="transShow ? 'gs-keyboard_arrow_down' : 'gs-keyboard_arrow_up' "></i>
      <!--<panel header="" :list="content" type="4" ></panel>-->
      <div class="bigContent" v-show="transShow">
        <div class="transItem" v-for="(item, index) in content">
          <h3>
            <i class="gs-user-circle"></i>
            <span :class="userId === item.desc? 'hightLight': ''">{{item.desc}}</span>
            <span class="pull-right time">{{item.date}}</span>
          </h3>
          <p class="transContent">
            {{item.title}}
          </p>
          <p class="transP">
           	转办至：<span :class="userId === item.recvOrgNames? 'hightLight': ''">{{item.recvOrgNames}}</span>
          </p>
        </div>
      </div>
    </group>
  </div>
</template>
<style lang="less" scpoed>
  .transList {
    .bigContent {
      padding: 10px;
      h3 {
        font-size: 14px;
        line-height: 40px;
        .time {
          float: right;
          font-weight: 400;
          font-size: 12px;
        }
      }
      .transItem {
        padding: 5px;
        background: #f8f8f8;
        border-top: 1px solid #f8f8f8;
        border-bottom: 1px solid #e2e2e2;
        border-radius: 5px;
        margin-bottom: 5px;
      }
    }
    .transContent {
      border-bottom: 1px dotted #e2e2e2;
      line-height: 20px;
      font-size: 14px;
    }
    .transP {
      color: #888;
      font-size: 14px;
    }
  }
</style>
<script>
  import { Cell, Popup, Panel, Group } from 'vux'

  export default {
    props: ['listTrans', 'userId'],
    data() {
      return {
        transShow: false
      }
    },
    components: {
      Cell,
      Popup,
      Panel,
      Group
    },
    created() {
    },
    methods: {

    },
    computed: {
      content: {
        get() {
          const result = []
          this.listTrans.forEach((value) => {
            result.push({
              title: value.disposeDescription,
              desc: value.disposePersonName,
              date: value.disposeTimeStr,
              recvOrgNames: value.recvOrgNames,
              recvPersonNames: value.recvPersonNames
            })
          })
          return result
        }
      }
    },
    mounted() {
    }

  }
</script>
