<template>
  <div>
  	this is demo1
    <div class="hello">
      <h1>{{ msg }}</h1>
      <!--管道形式进行过滤，验证条件。-->
      <x-input v-model="tel" v-validate="'required|mobile'" name="mobile" type="text"
               placeholder="手机号（必填）"></x-input>
      <p v-show="warns.has('mobile')" class="errors">
      {{ warns.first('mobile') }}
      </p>
      <!--邮箱-->
      <x-input v-validate="'required|email'" name="email" type="text"
               placeholder="邮箱（必填）"></x-input>
      <p v-show="warns.has('email')" class="errors">
      {{ warns.first('email') }}
      </p>
      <!--密码-->
      <x-input v-validate="'required|password'" name="password" type="text"
               placeholder="密码（必填）"></x-input>
      <p v-show="warns.has('password')" class="errors">
      {{ warns.first('password') }}
      </p>
      <x-button @click.native='Submit'>提交验证</x-button>
    </div>
  	<group title="机构树">
  		<org-check-list v-model="selectOrg" label="接收单位" :maxLength="20"></org-check-list>
  	</group>
  	<group title="领导列表">
  		<radio title="type" v-model="type" :options="['1', '2', '3']" @on-change="changeLeaderType"></radio>
  		<leader-selector :leaderType='type' v-model="users" label="送审领导" :defaultSelect="defaultSelect"></leader-selector>
  	</group>
  	<group title="附件选择">
  		<img-upload :localIds="fileOptions.localIds" :serverIds="fileOptions.serverIds" :imgMaxSum="fileOptions.imgMaxSum" @on-choose="chooseImg" @on-delete="deleteImg"></img-upload>
  	  <image-chooser @image-upload="onImageUploaded"></image-chooser>
      <div v-for="s in sids">{{s}}</div>
    </group>
  	<group title="微信分享">
  		<x-button type="primary" text="分享给好友" @click.native="weixinFriends"></x-button>
  		<x-button type="primary" text="分享文本" @click.native="weixinFriendsText"></x-button>
      <x-button type="primary" text="微信图片" @click.native="weixinChooseImage2"></x-button>
      {{serverId}}
  	</group>
  	<group title="视频录制/播放">
  		<x-button type="primary" text="录制视频" @click.native="recordVideo"></x-button>
  		<x-button type="primary" text="播放视频" @click.native="playVideo"></x-button>
  	</group>
  	<group title="音频录制/播放">
  		<x-button type="primary" text="录制音频" @click.native="startVoice"></x-button>
  		<x-button type="primary" text="播放音频" @click.native="playVoice"></x-button>
  	</group>
  	<group title="发送短信">
  		<x-button type="primary" text="短信" @click.native="sms"></x-button>
  	</group>
  </div>
</template>

<style lang="less">
@import "../../styles/common.less";

h1, h2 {
  font-weight: normal;
}

ul {
  list-style-type: none;
  padding: 0;
}

li {
  display: inline-block;
  margin: 0 10px;
}

a {
  color: #42b983;
}

.errors {
  color: #f00;
}
</style>


<script>
  import { Group, XButton, LoadingPlugin, Radio, XInput } from 'vux'
  import Vue from 'vue'
//  import VueResource from 'vue-resource'
//  import VueRouter from 'vue-router'

  // import OrgSelector from '../gsafetycomponents/OrgSelector'
  import OrgCheckList from './commoncompents/OrgCheckList'
  import LeaderSelector from '../gsafetycomponents/LeaderSelector'
  // imgUpload
  import ImgUpload from '../mycomponents/ImgUpload'
  import ImageChooser from '../mycomponents/ImageChooser'

  Vue.use(LoadingPlugin)

  export default {
    // 数据模型
    data() {
      return {
        tel: '', // 电话号码
        msg: '表单验证',
        selectOrg: [],
        users: ['1516964926673070'],
        type: '1',
        defaultSelect: ['1516964926673070'],
        sids: ['1', '3'],
        fileOptions: {
          localIds: [],
          serverIds: [],
          imgMaxSum: '9'
        },
        serverId: '',
        videoOptions: {
          id: '',
          path: ''
        },
        voiceOptions: {
          id: '',
          path: ''
        }
      }
    },

    // 组件
    components: {
      XInput,
      Group,
      OrgCheckList,
      ImgUpload,
      ImageChooser,
      XButton,
      LoadingPlugin,
      LeaderSelector,
      Radio
    },
    // vue实例创建后调用
    created() {
    },

    // 定义方法区
    methods: {
      onImageUploaded(result) {
        this.sids = result
      },
      Submit() {
//        this.$validator.validateAll()
        console.log(this.warns.has('mobile'))
        console.log(999)
//        当前表单是否有任何错误
        console.log(this.warns.any())
//        当前表单的所有错误
        console.log(this.warns.all())
        console.log(this.tel)
        if (this.warns.any()) {
          if (!this.tel) {
            alert('必填项不能为空')
          } else {
            alert('请按格式填写表单')
          }
        }
      },
      changeLeaderType(value, label) {
        this.users = []
        console.log(label)
      },
      chooseImg() { // 上传图片点击上传
        const options = {}
        this.$gsafety.chooseImage(options, (res) => {
          console.log(res)
        })
      },
      deleteImg(index) { // 删除图片自定义回调事件
        this.fileOptions.localIds.splice(index, 1)
        this.fileOptions.serverIds.splice(index, 1)
      },
      weixinFriends() {
        const options = {
          contentType: 1,
          type: 1,
          webpageUrl: 'https://www.baidu.com',
          title: '分享的标题',
          description: '分享内容描述'
        }
        this.$gsafety.weixinFriends(options)
      },
      weixinFriendsText() {
        const optionsWeixinFriendsText = {
          contentType: 0,
          type: 0,
          webpageUrl: 'https://www.baidu.com',
          title: '分享的文本给朋友',
          description: '分享的文本给朋友'
        }
        this.$gsafety.weixinFriends(optionsWeixinFriendsText)
      },
      //  tt
      weixinChooseImage() {

      },
      weixinChooseImage2() {
        const that = this
        wx.chooseImage({
          count: 1, // 默认9
          sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有
          sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
          success(res) {
            const localIds = res.localIds // 返回选定照片的本地ID列表，localId可以作为img标签的src属性显示图片
            console.log(localIds)

            wx.uploadImage({
              localId: localIds[0], // 需要上传的图片的本地ID，由chooseImage接口获得
              isShowProgressTips: 1, // 默认为1，显示进度提示
              success(resUploadImage) {
                const serverId = resUploadImage.serverId // 返回图片的服务器端ID
                console.log(serverId)
                alert(serverId)
                that.serverId = serverId
              }
            })
          }
        })
      },
      recordVideo() {
        const that = this
        that.$vux.loading.show({
          text: 'Loading'
        })
        this.$gsafety.startVideo(
          (res) => {
            that.videoOptions.id = res.id
            that.videoOptions.path = res.attachPath
            that.$vux.loading.hide()
          },
        // 取消
        (res) => {
          console.log(res)
          that.$vux.loading.hide()
        }
        )
      },
      playVideo() {
        this.$gsafety.playVideo(this.videoOptions)
      },
      sms() {
        const options = {
          person: ['10086', '10010'],
          content: 'YE'
        }
        this.$gsafety.sms(options)
      },
  // 录制音频
      startVoice() {
        const that = this
        that.$vux.loading.show({
          text: 'Loading'
        })
  // 录制音频
        this.$gsafety.startVoice(
            (res) => {
              that.voiceOptions.id = res.id
              that.voiceOptions.path = res.attachPath
              that.$vux.loading.hide()
            },
  // 取消
          (res) => {
            console.log(res)
            that.$vux.loading.hide()
          }
        )
      },
   // 播放音频
      playVoice() {
        this.$gsafety.playVoice(this.voiceOptions)
      }
    }
  }
</script>
