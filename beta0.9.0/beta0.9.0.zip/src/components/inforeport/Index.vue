<!--信息接报首页-->
<template>
  <div>
    <nav class="menu-part">
      <ul>
        <li :class="item.menuImg" @click="jumpPage(item.url)" v-for="(item,index) in menus" :key="index">
          <a><i></i></a>
          <p>{{item.menuName}}</p>
        </li>
      </ul>
    </nav>
    <section class="message-content">
      <header><i class="gs-commenting-o"></i>最近消息</header>
      <section>
        <div>
          <cell class="report-info-col"
                v-for="(item,index) in info"
                :key="index"
                @click.native="goDetailPage(item,index)"
                :class="{'dealing':item.userHandler=='1', 'activeColor':index == activeIndex}"
                v-show="isNew">
            <!--区域+标题-->
            <div class="document-title" :title="item.infoTitle" :class="{'Done':item.handleStatus === '4' && !(item.userHandler==='1')}">
              <div>
                <span>{{item.infoTitle}}</span>
              </div>
            </div>
            <!--标题下面的-->
            <div class="titleDown">
              <!--事件类型-->
              <span class="cell-icon" :class="iconShortClass(item.eventLevelCode,item.userRead)">{{iconShortTxt(item.eventType)}}</span>
              <!--判断状态   -->
              <span class="read-status" v-show="item.userHandler==='1'">
              待办
              </span>
              <!---->
              <span class="read-status dealDone"  v-show="item.handleStatus === '4' && !(item.userHandler==='1')">
              办结
            </span>
              <span class="unimp-status" v-show="item.handleStatus==='1'">
              草稿
            </span>
              <span class="descTime">{{item.createTimeStr}}</span>
            </div>
          </cell>
          <cell v-show="!isNew" class="report-info-col report-info">
            <p class="title">暂无最新消息！</p>
          </cell>
        </div>
        <router-link v-show="isNew" to="/deal" class="addMore">加载更多</router-link>
      </section>
    </section>
    <section class="amount-content" v-if="isHigherAuthorities === 1">
      <header><i class="gs-line-chart"></i>统计汇总<span @click.prevent="isSuperior = !isSuperior" :class="isSuperior ? 'gs-caret-down' : 'gs-caret-up' "></span></header>
      <div :class="isSuperior ? '' : 'nohig'">
      <div class="tab-width">
        <tab :line-width="2">
          <tab-item active-class="red" :selected="currentItem === item.itemValue" v-for="(item,index) in taglist" :key="index"
                  @on-item-click="getData(item.itemValue)">{{item.itemKey}}
          </tab-item>
        </tab>
      </div>
      <div class="moreposition">
        <router-link to="/statisbtn" class="moreStat addMore">更多</router-link>
      </div>
      <section class="canvas-position">
        <!--<img :src="amountImg">-->
        <div id="statChart" ref="statChart">
        </div>
      </section>
      </div>
    </section>
  </div>
</template>
<style lang="less" scoped>
  .canvas-position {
    position: relative;
  }
  .message-content ul .activeColor {
    background-color: #ebebeb;
  }
  .addMore {
    text-align: center;
    line-height: 2em;
    background: #fafafb;
    color: #555;
    display: block;
  }
  .moreStat {
    background-color: #fff;
  }
  .gs-commenting-o {
    color:#527baa;
    margin-right: 0.5em;
  }
  .menuNav {
    overflow: hidden;
  }
  li{
    list-style: none;
  }

  .menu-part{
    background: #fff;
    border-bottom:1px solid #e2e2e2;
    padding: 0 15px;
  }

  .menu-part ul{
    display: flex;
    flex-wrap: wrap;
    padding: 20px 0 10px 0;
  }

  .menu-part ul li{
    flex: 1;
    text-align: center;
    line-height: 40px;
    min-width:25%;
    max-width: 25%;
  }

  .menu-part ul li a{
    display: block;
    margin: auto;
    width: 12vw;
    height: 12vw;
    line-height:12vw;
    -webkit-border-radius: 12vw;
    -moz-border-radius: 12vw;
    border-radius: 12vw;
    text-align:center;
  }

  .menu-part ul li p{
    font-weight: bold;
    color: #666666;
    font-size: 13px;
  }

  .btn-1 a{
    background: url("../../assets/image/eventInfo/index/menu-btn-bg-3.png");
    background-size: 100% 100%;
    box-shadow: 2px 2px 5px #fecf7d;
  }

  .btn-2 a{
    background: url("../../assets/image/eventInfo/index/menu-btn-bg-2.png");
    background-size: 100% 100%;
    box-shadow: 2px 2px 5px #8cc3ff;
  }

  .btn-3 a{
    background: url("../../assets/image/eventInfo/index/menu-btn-bg-1.png");
    background-size: 100% 100%;
    box-shadow: 2px 2px 5px #f9b2ae;
  }

  .btn-4 a{
    background: url("../../assets/image/eventInfo/index/menu-btn-bg-4.png");
    background-size: 100% 100%;
    box-shadow: 2px 2px 5px #a3e8ac;
  }

  .btn-5 a{
    background: url("../../assets/image/eventInfo/index/menu-btn-bg-3.png");
    background-size: 100% 100%;
    box-shadow: 2px 2px 5px #fecf7d;
  }

  .btn-6 a{
    background: url("../../assets/image/eventInfo/index/menu-btn-bg-2.png");
    background-size: 100% 100%;
    box-shadow: 2px 2px 5px #8cc3ff;
  }

  .btn-7 a{
    background: url("../../assets/image/eventInfo/index/menu-btn-bg-4.png");
    background-size: 100% 100%;
    box-shadow: 2px 2px 5px #a3e8ac;
  }

  .btn-8 a{
    background: url("../../assets/image/eventInfo/index/menu-btn-bg-5.png");
    background-size: 100% 100%;
    box-shadow: 2px 2px 5px #9de6dc;
  }

  .menu-part a i{
    display: inline-block;
    width: 8vw;
    height: 8vw;
    background: url("../../assets/image/eventInfo/index/menu-icon-1.png");
    background-size: 100% 100%;
    vertical-align: middle;
  }

  .btn-2 a i{
    display: inline-block;
    width: 8vw;
    height: 8vw;
    background: url("../../assets/image/eventInfo/index/menu-icon-2.png");
    background-size: 100% 100%;
    vertical-align: middle;
  }

  .btn-3 a i{
    display: inline-block;
    width: 8vw;
    height: 8vw;
    background: url("../../assets/image/eventInfo/index/menu-icon-3.png");
    background-size: 100% 100%;
    vertical-align: middle;
  }

  .btn-4 a i{
    display: inline-block;
    width: 8vw;
    height: 8vw;
    background: url("../../assets/image/eventInfo/index/menu-icon-9.png");
    background-size: 100% 100%;
    vertical-align: middle;
  }

  .btn-5 a i{
    display: inline-block;
    width: 8vw;
    height: 8vw;
    background: url("../../assets/image/eventInfo/index/menu-icon-5.png");
    background-size: 100% 100%;
    vertical-align: middle;
  }

  .btn-6 a i{
    display: inline-block;
    width: 8vw;
    height: 8vw;
    background: url("../../assets/image/eventInfo/index/menu-icon-6.png");
    background-size: 100% 100%;
    vertical-align: middle;
  }

  .btn-7 a i{
    display: inline-block;
    width: 8vw;
    height: 8vw;
    background: url("../../assets/image/eventInfo/index/menu-icon-7.png");
    background-size: 100% 100%;
    vertical-align: middle;
  }

  .btn-8 a i{
    display: inline-block;
    width: 8vw;
    height: 8vw;
    background: url("../../assets/image/eventInfo/index/menu-icon-8.png");
    background-size: 100% 100%;
    vertical-align: middle;
  }

  .message-content{
    background: transparent;
    margin-top: 10px;
  }

  .message-content header{
    line-height: 46px;
    font-size: 18px;
    color: #555;
    background:#fff;
    border-bottom: 1px solid #e2e2e2;
    padding: 0 15px;
    font-weight: bold;
  }

  .message-content ul li{
    line-height: 25px;
    position: relative;
    margin: 5px 10px;
    background: #fafafa;
    padding: 5px 15px;
    border-radius: 5px;
    overflow: hidden;
  }
  .message-content .title {
    text-align: center;
    font-size: 18px;
    font-weight: bold;
  }
  .message-content ul li p:last-child{
    color: #999999;
  }

  .message-content .status{
    display: block;
    position: absolute;
    top: 0;
    right: 0;
    width: 24px;
    height: 24px;
    border-top-right-radius: 5px;
    background: #ef6b6b;
  }

  .message-content .dealing .status{
    background: #ffb818;
  }
  .message-content .done .status{
    background: #4c98ff;
  }
  .message-content .status .status-icon{
    position: absolute;
    color: #fff;
    font-weight: bold;
    right: 5px;
    top: 3px;
    font-size: 10px;
    line-height: 10px;
  }

  .message-content .dealing .status .status-icon{
    right: 3px;
    top: 1px;
    font-size: 6px;
    line-height: 6px;
  }

  .message-content .done .status .status-icon{
    right: 3px;
    top: 4px;
    font-size: 6px;
    line-height: 6px;
  }
  .message-content .btn-more{
    line-height: 40px;
    text-align: center;
    background: #fafafa;
    color: #8e8e8e;
  }

  .amount-content{
    background: #fff;
    margin-top: 10px;
  }

  .amount-content header{
    line-height: 40px;
    font-size: 18px;
    color: #000;
    border-bottom: 1px solid #eceef1;
    padding: 0 15px;
    font-weight: bold;
    position: relative;
    span {
      position: absolute;
      right: 0.5em;
      text-align: right;
      font-size: 1.5em;
      color: #666;
      top: 0.2em;
      width: 10em;
    }
  }
  .amount-content img{
    width: 100%;
  }
  .gs-message{
    color: #527baa;
    margin-right: 10px;
    vertical-align: -2px;
    font-size: 20px;
  }
  .gs-line-chart{
    color: #527baa;
    margin-right: 10px;
    vertical-align: -2px;
    font-size: 20px;
  }
  .message-content .desc span{
    display: block;
  }
  .gs-location{
    margin-right: 4px;
  }
  .gs-clock{
    margin-right: 4px;
  }
  #statChart{
    height: 300px;
    position: absolute;
    top: 1em;
    width: 100%;
    z-index: 99;
  }
  div.nohig {
    height: 0;
    overflow: hidden;
    padding: 0;
  }
  .tab-width {
    width:  60%;
  }
  .moreposition {
    width: 30%;
    position: relative;
    right: 0;
    display: block;
    height: 44px;
    top: -38px;
    float: right;
  }
  /*重新*/
  .titleDown {
    text-align: left;
  }
  .vux-label-desc .document-title  span.Done {
    color: #999;
  }
  .descTime {
    font-size: 12px;
    float: right;
    margin-top: 8px;
  }
  .report-info-col.activeColor {
    background-color: #ebebeb;
  }
  .searchInput {
    position: relative;
  p {
    text-align: center;
  }

  }
  .vux-search-box {
    z-index: 10001;
  }
  .loading {
    height: 46em;
    position: relative;
    background: #fff;
    overflow: hidden;
  }
  .loading img {
    width: 10%;
    margin: 50% auto 0 auto;
    display: block;
  }
  .info-list{
    background: #EDEDED;
  }

  .report-info-col{
    background: #fff;
    border-bottom: 1px solid #e2e2e2;
    border-top: 1px solid #fff;
    margin: 5px 0;
      &:before {
         display: none;
       }
  }
  .report-info {
    margin: 0;
    .title {
      font-size: 16px;
    }
  }
  /*状态*/
  .read-status{
    color: #900;
    font-weight: bold;
    font-size: 14px;
    margin-left: 20px;
  }
  .dealDone {
    color: #333;
  }
  .read-status .read{
    color: #ffffff;
    font-style: normal;
  }

  .read-status .unread{
    color: #36ba4f;
    font-style: normal;
  }
</style>
<script>
  import config from 'src/config'
  import { Tab, TabItem, Cell } from 'vux'

  export default{
    data() {
      return {
        myChart: null, // 当前页的echart实例
        activeIndex: null,
        detailUrl: '',
        menus: [],
        info: [],
        type: 'week',
        typename: '周',
        xname: '星期',
        currentItem: '2',
        taglist: [{ itemKey: '按周', itemValue: '2' },
          { itemKey: '按月', itemValue: '1' },
          { itemKey: '按季', itemValue: '0' }],
        isSuperior: false,
        isNew: true,
        amountImg: '../static/image/amountImg.png'
      }
    },
    // 组件
    components: {
      Tab,
      TabItem,
      Cell
    },
    created() {
      this.$store.dispatch('showPageLoading')
    },
    beforeRouteEnter(to, from, next) {
      next((vm) => {
        vm.activeIndex = null
        // 通过 `vm` 访问组件实例
        const leftOption = {
          showBack: false,
          backText: '',
          preventGoBack: true
        }
        vm.$store.commit('setHeaderLeft', leftOption)  // 进入首页 去掉回退
        vm.$store.commit('setHeaderTitle', '武汉市应急值守平台')  // 设置头部文字
        vm.$store.commit('setHeaderRightIcon', 'setting')  // 右边设置按钮
        vm.getNewestInfo()
      })
    },
    beforeRouteLeave(to, from, next) {
      const leftOption = {
        showBack: true,
        backText: '',
        preventGoBack: false
      }
      this.$store.commit('setHeaderLeft', leftOption)  // 离开首页 加上回退
      this.$store.commit('setHeaderRightIcon', '') // 隐藏右边按钮
      next()
    },
    computed: {
      // 与父组件通信用属性
      currentUser: {
        get() {
          return this.$store.state.user
        }
      },
      isHigherAuthorities: {
        get() {
          this.getChartData()
          return this.$store.state.user.typeCode
        }
      }
    },
    mounted() {
      this.getMenu()
      // console.log(this.currentUser.typeCode)
    },
    methods: {
      iconShortTxt(eventType) { // 四大类首字 作为cell头部 参数为事件类型code 返回类型首字
        let txt = ''
        this.info.map(() => {
          if (eventType.substring(0, 2) === '11') {
            txt = '自然灾害'
          } else if (eventType.substring(0, 2) === '12') {
            txt = '事故灾难'
          } else if (eventType.substring(0, 2) === '13') {
            txt = '卫生事件'
          } else if (eventType.substring(0, 2) === '14') {
            txt = '社会安全'
          } else if (eventType.substring(0, 2) === '30') {
            txt = '预警信息'
          } else if (eventType.substring(0, 2) === '40') {
            txt = '其它信息'
          }
          return txt
        })
        return txt
      },
      iconShortClass(eventLevelCode, userRead) { // 四大类首字 作为cell头部 参数为事件类型code 返回类型颜色样式类
        let colorCss = ''
        console.log(userRead)
        if (eventLevelCode === '1') {
          colorCss = 'red'
        } else if (eventLevelCode === '2') {
          colorCss = 'orange'
        } else if (eventLevelCode === '3') {
          colorCss = 'yellow'
        } else if (eventLevelCode === '4') {
          colorCss = 'blue'
        }
        if (userRead === '0') {
          colorCss += ' unread'
        }
        return colorCss
      },
      getData(val) {
        if (val === '0') {
          this.type = 'season'
          this.xname = '季度'
          this.typename = '季'
          this.getChartData()
        } else if (val === '1') {
          this.type = 'month'
          this.typename = '月'
          this.xname = '月份'
          this.getChartData()
        } else {
          this.type = 'week'
          this.typename = '周'
          this.xname = '星期'
          this.getChartData()
        }
      },
      //  得到图表数据
      getChartData() {
        const URL = `${config.siteUrl}/eventinforpt/getListByType/${this.type}?date=`
        this.axios.get(URL)
          .then((response) => {
            if (response.data.code === 200) {
              this.drawLineChart(response.data.response.result)
            }
          })
          .catch(() => {
          })
      },
        // 为图表赋值
      drawLineChart(chartData) {
        const options = {
          title: {
            text: `近${chartData.length}个${this.typename}信息数量统计`,
            textStyle: {
              color: '#4c98ff'
            }
          },
          xAxis: [{
            type: 'category',
            name: this.xname,
            data: []
          }],
          yAxis: [{
            type: 'value',
            name: '数量'
          }],
          series: []
        }
        const colors = ['#b3b3b3', '#46b79e', '#fec469', '#6cb2d7', '#fe7769', '#e28de3']
        if (chartData && chartData instanceof Array) {
          chartData.forEach((dataItem, index) => {
            const seriesObj = {
              name: '数量',
              type: 'bar',
              stack: '统计结果',
              itemStyle: {
                normal: {
                  color: colors[index % 6],
                  label: { show: true, position: 'top' }
                }
              },
              data: []
            }
            for (let i = 0; i < chartData.length; i++) {
              if (i === index) {
                seriesObj.data.push(dataItem.total)
              } else {
                seriesObj.data.push('-')
              }
            }
            options.xAxis[0].data.push(dataItem[this.type])
            options.series.push(seriesObj)
          })
        }
        if (this.myChart) {
          this.myChart.setOption(options, true)
        } else {
          this.$store.dispatch('initChart').then((echarts) => { // 异步加入echart插件
            // ...加载echarts插件后的回调
            if (this.$refs.statChart) {
              this.myChart = echarts.init(this.$refs.statChart) // 根据当前页dom初始化echart实例
              this.myChart.setOption(options, true)
            }
          })
        }
      },
      getMenu() {
        const URL = `${config.siteUrl}/eventInfo/eventInfoMenu`
        const that = this
        this.axios.get(URL)
          .then((response) => {
            if (response.data.code === 200) {
              that.menus = response.data.response.menus
            }
          })
          .catch(() => {
          })
      },
      getNewestInfo() {
        const that = this
        const URL = `${config.siteUrl}/eventInfo/findByidDesc`
        that.info = []
        that.axios.get(URL)
          .then((res) => {
            that.$store.dispatch('hidePageLoading')
            if (res.data.code === 200) {
              if (res.data.response.result) {
                const messArr = Object.values(res.data.response.result)
                that.info = that.info.concat(messArr)
                if (that.info.length > 0) {
                  that.isNew = true
                } else {
                  that.isNew = false
                }
              }
            }
          })
          .catch(() => {
          })
      },
      handleStr(handleStatus) {
        if (handleStatus === '1') {
          return '待办'
        } else if (handleStatus === '0') {
          return ''
        }
        return '未处理'
      },
      jumpPage(r) {
        if (r) {
          this.$store.dispatch('showPageLoading')
          this.$router.push(r)
        } else {
          alert('此功能正在开发中，敬请期待~~')
        }
      },
      // 点击头部右边跳转用户审核修改密码页面
      headerRightClick() {
        const r = '/user'
        this.$router.push(r)
      },
      goDetailPage(item, index) {
        this.activeIndex = index
        let r = ''
//        点击去掉红点
        if (item.userRead === '0') {
          const readUrl = `${config.siteUrl}/eventInfo/markread/${item.eventInfoId}`
          this.axios.post(readUrl, '')
            .then(() => {
            })
            .catch(() => {
            })
          item.userRead = '1'
        }
        r = item.info.link.view
        this.$store.dispatch('showPageLoading')
        if (r === '') {
          this.$router.push('/error')
          return
        }
        this.$router.push(r)
      },
      getTime() {
        const date = new Date()
        const year = date.getFullYear()
        let month = date.getMonth() + 1
        if (month >= 1 && month <= 9) {
          month = `0${month}`
        }
        const currentdate = `${year}${month}`
        return currentdate
      }
    }
  }

</script>
