<template>
  <div class="instruction">
    <div  class="main_panel" v-show="showinstr">

      <!--end效果图-->
      <comments-item ref="comments" :scrollH="scrollH"></comments-item>
    </div>
  </div>
</template>
<style lang="less" scoped>
  .main_panel {
    margin-top: 10px;
  }
  .tabNav {
    /*position: fixed;*/
    /*top: 46px;*/
    position: relative;
    z-index: 9;
    width: 100%;
  }
  .instruction {
    /*margin-top: 3em;*/
  }
</style>
<script>
  import { Cell, Scroller, Tab, TabItem, Box, Popup, Group, XTextarea, XButton } from 'vux'
  import Vue from 'vue'
  import VueResource from 'vue-resource'
  import { siteUrl } from '../../../../utils/common'
  import TransitionPage from './../../../mycomponents/TransitionPage'
  import InstructItem from './InstructItem'
  import InstructWatched from './InstructWatched'
  import CommentsItem from './CommentsItem'

  Vue.use(VueResource)

  export default {
    // 组件
    components: {
      Cell,
      Scroller,
      InstructItem,
      TransitionPage,
      Tab,
      TabItem,
      InstructWatched,
      CommentsItem,
      Box,
      Popup,
      XTextarea,
      XButton,
      Group

    },
    computed: {},

    beforeRouteEnter(to, from, next) {
      next((vm) => {
        if (!vm.$store.state.headerShow) {
          vm.scrollH = '-0'
        }
        // 通过 `vm` 访问组件实例
        vm.$store.commit('setHeaderTitle', '转办督办') // 设置头部文字
        vm.$refs.comments.loadPage(0, true)
        vm.loadPage(0, true)
        vm.getData('instr')
      })
    },
    beforeCreate() {
      const that = this
      this.$nextTick(() => {
        that.$store.dispatch('showPageLoading')
      })
    },
    // 页面加载
    created() {
      this.id = this.$router.history.current.params.id
    },
    mounted() {
    },
    // 数据模型
    data() {
      return {
//        scroller高度问题
        scrollH: '-54',
//          加载数据小飞机
        beginPic: true,
        checkMessage: '',
//        督办
        showDetail: 'false',
//        批示
        showinfo: 'false',
//        转办
        showinstr: 'true',
        eventBase: {
          infoId: '',
          infoTitle: '',
          infoAddress: '',
          eventTypeName: '',
          incidentDateStr: '',
          reportDateStr: '',
          eventDescription: '',
          eventMeasures: '',
          reportPerson: '',
          reportPersonPhone: '',
          org: {
            orgName: ''
          }
        },
        instList: [],
        leaderId: '',
        instructionId: '',
        beInfo: {
          instructionUsername: '',
          instructionTimeStr: '',
          instructionContent: ''
//          attachs: [{
//            name: '交通事故处理法则第二版.doc'
//          }]
        },
        checkList: [],
        id: '',
        taglist: [
          { itemKey: '转办', itemValue: 'instr' },
          { itemKey: '督办', itemValue: 'detailInfo' }
        ],
        currentItem: [],
        instructList: [],
//        转办
        instructTransList: [],
        page: 0,
        size: 10,
        transPage: 0,
        transSize: 10,
        imgsrc: require('assets/image/img-05NotExist.png'),
        pullup_config: {
          content: '',
          downContent: '数据加载中...',
          upContent: '',
          loadingContent: '数据加载中...',
          hight: 60
        },
        pulldown_config: {
          content: '',
          downContent: '松开刷新',
          upContent: '松开刷新',
          loadingContent: '数据加载中...',
          hight: 60
        },
        // 提示图
        promptDiagram: {
          show: false,
          imgUrl: '',
          content: '',
          myColor: {
            type: String,
            default: '#e45050'
          }
        }
      }
    },
    // 方法
    methods: {
      getData(item) {
        this.checkList = []
        const that = this
        // switch items
        const oldItem = that.currentItem
        that.currentItem = item
        that.changeTab(item)
        if (oldItem !== item) {
          this.attachs = []
          that.attachExist = false
        }
      },
      changeTab(item) {
        if (item === 'instruInfo') {
          this.showinfo = true
          this.showinstr = false
          this.showDetail = true
        } else if (item === 'instr') {
          this.showinstr = true
          this.showinfo = false
          this.showDetail = true
        } else {
          this.showinstr = true
          this.showinfo = false
          this.showDetail = true
        }
      },
      getInstruInfo(val) {
        const that = this
        const URL = `${siteUrl}${this.$REST.INSTRUCT.VIEW}/${val}`
        this.$http.get(URL).then((response) => {
          if (response.body.code === 200) {
            if (response.body.response) {
              that.isEdit = true
              that.beInfo = response.body.response
              that.instructionId = that.beInfo.id
              that.leaderId = that.beInfo.instructionUserId
            }
          }
        })
      },
      /* getInstruList(val) {
        const that = this
        const URL = `${siteUrl}${this.$REST.INSTRUCT.LIST}/${val}`
        this.$http.get(URL).then((response) => {
          if (response.body.code === 200) {
            if (response.body.response) {
              that.instList = response.body.response
            }
          }
        })
      }, */
      getEventBase(val) {
        const that = this
        const URL = `${siteUrl}${this.$REST.EventInfo.VIEW}/${val}`
        this.$http.get(URL).then(function (response) {
          if (response.body.code === 200) {
            that.eventBase = response.body.response
            const dtos = that.eventBase.applyRecordDtos
            if (dtos) {
              const dtosValArr = Object.values(dtos)
              dtosValArr.forEach((value) => {
                that.checkList.push(value)
              })
            }
            const dto = that.eventBase.applyRrecord
            if (dto) {
              const dtoValArr = Object.values(dto)
              dtoValArr.forEach((value) => {
                that.checkList.push(value)
              })
            }
            this.title = this.eventBase.infoTitle
//            this.convertUsers(this.eventBase)
          }
        })
      },
      loadPage(page, reload) {
        const that = this
        if (!reload) {
          let pageChange = page
          pageChange += 1
          this.page = pageChange
        }
        const URL = `${siteUrl}${this.$REST.INSTRUCT.LISTINSTR}?page=${this.page}&size=${this.size}`
        const data = {}
        this.$http.post(URL, data).then((res) => {
          if (res.body.code === 200) {
            that.$store.dispatch('hidePageLoading')
            that.news = res.body.response.list
            if (page === 200) {
              this.page = 0
              this.instructList = []
              // 添加加载效果图
              this.promptDiagram.show = true // 开启效果图
              this.promptDiagram.imgUrl = '../static/image/loading.gif'
              this.promptDiagram.content = ''
            }
            if (that.news.length > 0) {
              that.beginPic = false
              if (that.news) {
                const newsValArr = Object.values(that.news + that.news)
                newsValArr.forEach((value) => {
                  that.instructList.push(value)
                })
              }
            } else if (that.instructList.length <= 0) {
              that.promptDiagram.show = false
              that.promptDiagram.show = true
              that.promptDiagram.imgUrl = '../static/image/img-02Notdata.png'
              that.promptDiagram.content = '暂无数据'
            }
          }
        })
      }
    }
  }
</script>
