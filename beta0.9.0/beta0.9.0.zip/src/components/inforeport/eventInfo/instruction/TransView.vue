<template>
  <div class="transInfo">
    <group title="领导批示" v-if="data.person !== ''">
      <box gap="10px 10px">
        <p v-if="data.person !== ''"><span class="infoName">领导姓名：</span><span class="fontInfoCss">{{data.person}}</span></p>
        <p v-if="data.content !== ''"><span class="infoName">批示内容：</span><span class="fontInfoCss">{{data.content}}</span></p>
        <p v-if="data.date !== ''"><span class="infoName">批示时间：</span><span class="fontInfoCss">{{data.date}}</span></p>
      </box>
    </group>
    <group class="unit" title="办理信息">
      <!--<box gap="0 15px">-->
      <box>
        <p><span class="infoName">转办单位：</span><span class="fontInfoCss">{{data.disposeOrgName}}</span></p>
        <p><span class="infoName">转办意见：</span><span class="fontInfoCss">{{data.disposeDescription}}</span></p>
        <p><span class="infoName">转办时间：</span><span class="fontInfoCss">{{data.disposeTimeStr}}</span></p>
        <div><span class="show-attach">转办附件:</span>
          <!--<div class="attach-img">-->
            <!--<slide-img @showFullScreen="showFullScreen" :imgs="attachs"></slide-img>-->
          <!--</div>-->
          <div class="attach-img">
            <div class="detail-img" @click="expandBig(index)" v-for="(attach,index) in attachs" :key="index">
              <img :src="getAttachPath(attach.attachPath)">
            </div>
          </div>
        </div>
      </box>
    </group>
    <group title="关联信息">
      <box gap="10px 10px">
        <p class="line_hidden"><span  class="release" @click.stop="relInfo()">{{data.infoTitle}}</span></p>
      </box>
    </group>
    <group title="回复历史" class="backMassage">
      <group v-for="(item,index) in backMsg" :key="index">
        <div class="backMsg">
          <div>
            <i class="gs-user-circle"></i>
            <span class="backPerson">{{item.disposePersonName}}：</span>
            <span class="backContentt">{{item.disposeTimeStr}}</span>
          </div>
          <span class="backContent">{{item.disposeDescription}}</span>
        </div>
      </group>
    </group>
    <group class="btnPri">
      <x-button text="回复" type="theme" class="popup-select-btn" @click.native.stop="toBack(data.disposeDescription)"></x-button>
      <x-button text="返回" type="default" class="popup-select-btn" @click.native.stop="toCancel"></x-button>
    </group>
    <watch-popup :popMsg="objPop" ref="popShow" v-on:backChange="backMssg($event)"></watch-popup>
  </div>

</template>
<style type="less" scoped>
  .transInfo {
    margin-bottom: 8em;
  }
  .transInfo button.weui-btn, .transInfo input.weui-btn {
    width: 94%;
  }
  .transInfo > div {
    margin-bottom: 1em;
  }
  .backName{
    float: left;
    color: #0b6694;
  }
  .backMsg {
    margin: 17px;
    text-align: left;
    line-height: 28px;
  }
  .backContent{
    word-wrap: break-word;
    font-size: 15px;
    color: #8a8888;
  }
  .backPerson {
    font-weight: 700;
  }
  .backContentt {
    word-wrap: break-word;
    float: right;
    font-size: 12px;
    color: #444;
  }
  .show-attach{
    float: left;
    margin: 10px 0px;
    display: inline-block;
    width: 85px;
    text-align: center;
    padding: 0 10px;
  }
  .release {
    color: #03A9F4;
  }
  .transInfo .btnPri {
    position: fixed;
    bottom: 0;
    width: 100%;
    margin-bottom: 0;
  }
  .backMassage {
    margin-bottom: 8em;
  }
  .backMassage h3 {
    margin-bottom: -1em;
    color: #999ba1;
    font-weight: normal;
    margin-left: 1em;
  }
  .weui-cell:before {
    display: none;
  }
  .infoLead [data-v-4948700e], .repTime[data-v-4948700e] {
    border-bottom: none;
  }
  .unit p {
    border-bottom:1px solid #ddd;
    padding: 0 10px;
  }
  .unit p:nth-last-child(1) {
    border: none;
  }
  .file {
    text-align: left;
  }
  .transInfo p {
    line-height: 3em;
    text-align: left;
  }
  .infoName {
    display: inline-block;
    width: 90px;
    text-align: right;
  }
  button.weui-btn, input.weui-btn {
    width: 95%;
    margin: 10px;
  }
  .attach-img{
    text-align: center;
  }
  .nShow {
    display: none;
  }
  .fontInfoCss {
    font-size: 15px;
    color: #8a8888;
  }
  .line_hidden {
    overflow: hidden;
    text-overflow:ellipsis;
    white-space: nowrap;
  }
  .detail-img {
    width: 100px;
    height: 100px;
    float: left;
    margin: 10px;
  }
</style>
<script>
  import { Cell, Scroller, XButton, Flexbox, FlexboxItem, Group, XTextarea, Box } from 'vux'
  import Vue from 'vue'
  import VueResource from 'vue-resource'
  import { siteUrl, fileserver } from '../../../../utils/common'
  import TransitionPage from './../../../mycomponents/TransitionPage'
  import InstructItem from './InstructItem'
  import watchPopup from './watchPopup'
  import SlideImg from '../../commoncompents/slideImg'

  Vue.use(VueResource)

  export default {
    // 组件
    components: {
      Flexbox,
      FlexboxItem,
      Cell,
      Scroller,
      XButton,
      InstructItem,
      TransitionPage,
      Group,
      XTextarea,
      Box,
      watchPopup,
      SlideImg
    },
    props: ['id'],
    // 数据模型
    data() {
      return {
        repeatInfo: '批示的信息',
        infoList: {},
        data: {
        },
        backMsg: [],
//        传到弹窗子组件的值
        objPop: {},
        watchObj: {},
        eventInfoId: '',
        transactContent: '',
        transactUserName: '',
        commonInstructionDto: '',
        attachs: [],
        currentUser: {}
      }
    },
    beforeCreate() {
      const that = this
      this.$nextTick(() => {
        that.$store.dispatch('showPageLoading')
      })
    },
    created() {
      this.currentUser = this.$store.state.user
    },
    // 方法
    methods: {
      expandBig(i) { // 全屏查看图片
        this.$router.push(`/instruct/bigImg/${this.id}/${i}`)
      },
      loadPage(id) {
        const that = this
        const url = `${siteUrl}/eventInfo/transact/load/${id}`
        this.$http.get(url).then((res) => {
          if (res.body.code === 200) {
            that.$store.dispatch('hidePageLoading')
            const result = res.body.response
            that.eventInfoId = result.eventInfoId
            that.data = result
            that.infoList = result.eventInfoDto
            that.transactContent = result.transactContent
            that.backMsg = result.feedBackDtos
//  问题所在
            that.watchObj.infoId = result.eventInfoId
            that.watchObj.transactId = result.eventDisposeId


            that.objPop.watchObj = this.watchObj
            that.objPop.transactContent = result.transactContent
            that.transactUserName = result.transactUserName
//  判断状态
            that.objPop.readType = result.readType
            if (result.attachs) {
              that.attachs = JSON.parse(result.attachs)
              that.$store.commit('setBigSrc', that.attachs)
            } else {
              this.attachs = ''
            }
          }
        })
      },
      toBack(txt) {
        this.$refs.popShow.showPop(txt)
      },
      getAttachPath(item) {
        return fileserver + item
      },
      backMssg(msg) {
        this.backMsg.push({ disposeDescription: msg,
          disposePersonName: this.currentUser.username,
          disposeTimeStr: this.data.disposeTimeStr })
      },

      relInfo() {
        const r = `/report/infoview/${this.eventInfoId}`
        // const r = `/deal/view/${true}/${this.eventInfoId}`
        this.$router.push(r)
      },
      toCancel() {
        window.history.go(-1)
      },
      isLeaderCss(status) {
        let classNam
        if (status) {
          classNam = 'nShow'
        } else {
          classNam = 'nShow'
        }
        return classNam
      }
    }
  }
</script>
