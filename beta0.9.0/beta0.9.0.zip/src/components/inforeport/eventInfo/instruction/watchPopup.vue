<template>
  <div class="transInfo">
    <popup v-model="showV" class="popContainer">
      <div class="head">
        <span class="headBtnL" @click="HandleCancel">取消</span>
        <div class="headTitle">{{title}}</div>
        <span class="headBtnR" @click="handleCommit">✔ 确定</span>
      </div>
      <box gap="10px 10px">
        <div class="popup0">
          <group>
            <x-textarea readonly :value="disposeDescription" placeholder=""></x-textarea>
          </group>
          <group>
            <x-textarea v-model="backContent" placeholder="此处输入回复内容"></x-textarea>
          </group>
        </div>
      </box>
    </popup>
  </div>
</template>
<style type="less" scoped>
  .vux-popup-dialog {
    height: 94% !important;
  }
  .head {
    color: #444;
    background-color: #f2f2f2;
    text-align: center;
    font-weight: 700;
    line-height: 56px;
    font-size: 16px;
  }
  .headTitle {
    display: inline-block;
  }
  .headBtnL {
    float: left;
    color: #a5a4a4;
    font-weight: normal;
    padding: 0 1em;
  }

  .headBtnR{
    float: right;
    color: #0faaff;
    font-weight: normal;
    padding: 0 1em;

  }

</style>
<script>
  import { Cell, Scroller, XButton, Flexbox, FlexboxItem, Group, XTextarea, Box, Popup, ConfirmPlugin } from 'vux'
  import Vue from 'vue'
  import VueResource from 'vue-resource'
  import { siteUrl } from '../../../../utils/common'
  import TransitionPage from '../../../mycomponents/TransitionPage'
  import InstructItem from './InstructItem'

  Vue.use(VueResource)
  Vue.use(ConfirmPlugin)


  export default {
    props: ['popMsg'],
    // 组件
    components: {
      Flexbox,
      FlexboxItem,
      Cell,
      Scroller,
      XButton,
      InstructItem,
      TransitionPage,
      Group,
      XTextarea,
      Box,
      Popup,
      ConfirmPlugin
    },
    // 数据模型
    data() {
      return {
        showV: false,
        disposeDescription: '测试信息',
        backContent: '',
        title: '',
        comfirmTitle: '确认回复？',
        load: '恢复中，请稍后....'
      }
    },
    created() {
    },
    // 方法
    methods: {
      showPop(obj) {
        this.showV = true
        this.disposeDescription = obj
        if (this.popMsg.disposeType === '7') {
          this.title = '转办'
        } else if (this.popMsg.disposeType === '13') {
          this.title = '督办'
        }
      },
      HandleCancel() {
        this.showV = false
        this.backContent = ''
      },
      handleCommit() {
        if (!this.backContent) {
          alert('回复内容不能为空')
          return false
        }
        this.$emit('backChange', this.backContent)
        const that = this
        this.showV = true
        const url = `${siteUrl}/eventInfo/transact/feedbackSupervise`
        const data = this.popMsg.watchObj
        data.opinionContent = that.backContent

        that.$vux.confirm.show({
          title: this.comfirmTitle,
          content: '',
          onConfirm() {
            that.loadingShow = true
            that.loadText = that.load
            that.$http.post(url, data).then((response) => {
              that.loadingShow = false
              if (response.status === 200) {
//                $gsafety.closeWindow()
                alert('回复成功！')
                that.$vux.confirm.hide()
                that.showV = false
                that.backContent = ''
              }
            }, () => {
              that.$vux.confirm.hide()
              that.loadingShow = false
              this.showV = false
              alert('回复失败！')
            })
          }
        })
        return false
      }
    }
  }
</script>
