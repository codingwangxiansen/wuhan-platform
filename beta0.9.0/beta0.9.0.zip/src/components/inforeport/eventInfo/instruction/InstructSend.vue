<!--
	转办页面

	页面可以新增领导批示意见

	用户选择机构，点击转办后发送给对应机构
 -->
<template>
  <div class="infoSend">
  	<box gap="10px 10px">
  		<group title="信息转办">
  		    <org-check-list v-model="orgs" label="接收单位" :maxLength="20"></org-check-list>
		    <!--<leader-selector leaderType='3' v-model="selectLeadList" label="接收人员"></leader-selector>-->
  		</group>
	    <group title="编辑转办信息">
		  	<x-textarea title="" v-model="comment" placeholder="请输入转办信息"></x-textarea>
	    </group>
      <group title="图片上传">
        <img-upload :localIds="localIds" :serverIds="serverIds" :imgMaxSum="imgMaxSum"
                    @on-choose="chooseImg"@on-delete="deleteImg"></img-upload>
      </group>
      <group title="关联信息">
        <box>
          <p><span class="release" @click.stop="relInfo()">{{eventBase.infoTitle}}</span></p>
        </box>
      </group>
	    <divider></divider>
	  	<x-button mini type="default"
	  		 @click.native="commit">确定</x-button>
	  	<x-button mini type="theme" @click.native="goback">返回</x-button>
	</box>
  </div>
</template>
<script>
import { ConfirmPlugin, Group, CellBox, Checklist, Cell, Divider, XButton, Box, XTextarea } from 'vux'
import Vue from 'vue'
// import _ from 'lodash'
// import VueResource from 'vue-resource'
// import VueRouter from 'vue-router'
import OrgSelector from '../../../gsafetycomponents/OrgSelector'
import OrgCheckList from '../../commoncompents/OrgCheckList'
import LeaderSelector from '../../../gsafetycomponents/LeaderSelector'
import UserSelector from '../../../gsafetycomponents/UserSelector'
import ImgUpload from '../../../mycomponents/ImgUpload'
import { siteUrl } from '../../../../utils/common'

Vue.use(ConfirmPlugin)

export default {
  mounted() {
  },
  components: {
    ConfirmPlugin,
    Group,
    Checklist,
    Cell,
    Divider,
    XButton,
    CellBox,
    Box,
    XTextarea,
    OrgSelector,
    OrgCheckList,
    LeaderSelector,
    UserSelector,
    ImgUpload
  },

  beforeRouteEnter(to, from, next) {
      // cons
    next((vm) => {
      if (from.name === 'InfoView') {
        return
      }
      vm.init()
    }
    )
  },

  methods: {
//    change() {
//    },
    init() {
      this.id = this.$router.history.current.params.id
      this.msgid = this.$router.history.current.query.msgid
      this.localIds = []
      this.serverIds = []
      this.selectLeadList = []
      this.orgs = []
      this.comment = ''
      this.getEventBase()
    },
    /*
     * 提交呈报
     */
    commit() {
      const vm = this
      this.$vux.confirm.show({
        title: '确认转办？',
        content: '',
        onConfirm() {
          const url = `${siteUrl}/eventInfo/transact/instructionTransactSave`
          const data = {
            attachId: vm.serverIds,
            // attachId: ['2018012310192157', '2018012310162514'],
            transactOrgName: vm.orgs.join(','),
            transactUserName: vm.selectLeadList.join(','),
            opinionContent: vm.comment,
            infoId: vm.id,
            instructionId: vm.msgid,
            disposeType: '5'
          }
          vm.$http.post(url, data).then(() => {
         // 返回码不正确时直接结束
            vm.$vux.toast.text('批示转办成功')
            vm.$router.go(-1)
          })
        }
      })
    },
    /*
    * 取消
    */
    goback() {
      this.$router.go(-1)
    },
    chooseImg() { // 上传图片点击上传
      const vm = this
      const options = {}
      this.$gsafety.chooseImage(options, (res) => {
        if (res) {
          vm.localIds.push(res.url)
          const localImgId = res.url
          let imgSrc
          if (localImgId.indexOf('storage') > -1) {
            const start = localImgId.indexOf('storage')
            imgSrc = localImgId.substring(start + 7, localImgId.length)
          } else {
            imgSrc = localImgId
          }
          const jsonObj = { localId: imgSrc }
          this.$gsafety.uploadImage(jsonObj, (ress) => {
            if (ress.id) {
              vm.serverIds.push(ress.id)
//                vm.alertShow('图片上传成功')
              vm.$vux.toast.text('图片上传成功', 'middle')
            } else {
//                vm.alertShow('上传图片失败')
              vm.$vux.toast.text('上传图片失败', 'middle')
            }
          })
        }
      })
    },
    deleteImg(index) { // 删除图片自定义回调事件
      console.log('delete')
      this.localIds.splice(index, 1)
      this.serverIds.splice(index, 1)
    },
    relInfo() {
      const r = `/report/infoview/${this.id}`
      this.$router.push(r)
    },
    getEventBase() {
      const URL = `${siteUrl}${this.$REST.EventInfo.VIEW}/${this.id}`
      this.$http.get(URL).then(
        (response) => {
          if (response.body.code === 200) {
            this.eventBase = response.body.response
          } else {
            console.log('error')
          }
        })
    }
  },
  data() {
    return {
      id: '',
      msgid: '',
      fullValues: [],
      labelPosition: '',
      error: '',
      orgList: [],
      leaderList: [],
      selectOrgList: [],
      selectLeadList: [],
      comment: '',
      orgs: [],
      imgMaxSum: '3',
      localIds: [],
      serverIds: [],
      eventBase: {}
    }
  }
}
</script>

<style scoped>
.error {
  padding-left: 15px;
  line-height: 28px;
  color: #888;
  font-size: 12px;
}
.release {
  color: #03A9F4;
  float: left;
  line-height: 46px;
  margin-left: 10px;
}
</style>
