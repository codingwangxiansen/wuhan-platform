<template>
  <div id="instruction">
    <div class="tabNav">
      <tab :line-width="2">
        <tab-item
          active-class="red"
          :selected="currentItem === item.itemValue"
          v-for="(item, index) in taglist"
          :key="index"
          @on-item-click="getData(item.itemValue)">
          {{item.itemKey}}
        </tab-item>
      </tab>
    </div>
    <div  class="" v-show="showinstr">
      <!--办理信息-->
      <trans-view ref="loadInit" :id="id"></trans-view>
    </div>

    <!--处理过程-->
    <div v-show="showDetail" class="">
      <trans-process ref="loadInitPro" :id="id"></trans-process>
    </div>
  </div>
</template>

<script>
    import { Cell, Scroller, Tab, TabItem, Box, Popup, Group, XTextarea, XButton } from 'vux'
    import Vue from 'vue'
    import VueResource from 'vue-resource'
    // import { siteUrl } from '../../utils/common'
    import TransitionPage from './../../../mycomponents/TransitionPage'
    import InstructItem from './InstructItem'
    import TransProcess from './TransProcess'
    import CommentsItem from './CommentsItem'
    import TransView from './TransView'

    Vue.use(VueResource)
    export default {
      // 组件
      components: {
        Cell,
        Scroller,
        InstructItem,
        TransitionPage,
        Tab,
        TabItem,
        TransProcess,
        CommentsItem,
        TransView,
        Box,
        Popup,
        XTextarea,
        XButton,
        Group

      },
      computed: {},
      beforeRouteEnter(to, from, next) {
        next((vm) => {
          // 通过 `vm` 访问组件实例
          vm.id = vm.$router.history.current.params.id
          vm.$store.commit('setHeaderTitle', '转办督办') // 设置头部文字
          // vm.loadPage(0, true)
          vm.$refs.loadInit.loadPage(vm.id)
          vm.$refs.loadInitPro.loadPage(vm.id)
          vm.getData('instr')
        })
      },
      beforeCreate() {
        const that = this
        this.$nextTick(() => {
          that.$store.dispatch('showPageLoading')
        })
      },
      // 页面加载
      created() {
        this.id = this.$router.history.current.params.id
      },
      mounted() {
      },
      data() {
        return {
//        加载数据小飞机
          beginPic: true,
          checkMessage: '',
//        处理过程
          showDetail: 'false',
//        批示
//           showinfo: 'false',
//        处理信息
          showinstr: 'true',
          eventBase: {
            infoId: '',
            infoTitle: '',
            infoAddress: '',
            eventTypeName: '',
            incidentDateStr: '',
            reportDateStr: '',
            eventDescription: '',
            eventMeasures: '',
            reportPerson: '',
            reportPersonPhone: '',
            org: {
              orgName: ''
            }
          },
          instList: [],
          leaderId: '',
          instructionId: '',
          beInfo: {
            instructionUsername: '',
            instructionTimeStr: '',
            instructionContent: ''
          },
          checkList: [],
          id: '',
          taglist: [
            { itemKey: '办理信息', itemValue: 'instr' },
            { itemKey: '处理过程', itemValue: 'detailInfo' }
          ],
          currentItem: [],
          instructList: [],
//        处理信息
          instructTransList: [],
          page: 0,
          size: 10,
          transPage: 0,
          transSize: 10,
          imgsrc: require('assets/image/img-05NotExist.png'),
          pullup_config: {
            content: '',
            downContent: '数据加载中...',
            upContent: '',
            loadingContent: '数据加载中...',
            hight: 60
          },
          pulldown_config: {
            content: '',
            downContent: '松开刷新',
            upContent: '松开刷新',
            loadingContent: '数据加载中...',
            hight: 60
          },
          // 提示图
          promptDiagram: {
            show: false,
            imgUrl: '',
            content: '',
            myColor: {
              type: String,
              default: '#e45050'
            }
          }
        }
      },
      // 方法
      methods: {
        getData(item) {
          this.checkList = []
          const that = this
          const oldItem = that.currentItem
          that.currentItem = item
          that.changeTab(item)
          if (oldItem !== item) {
            this.attachs = []
            that.attachExist = false
          }
        },
        changeTab(item) {
          if (item === 'instr') {
            this.showinstr = true
            // this.showinfo = false
            this.showDetail = false
            // location.reload()
          } else {
            // 处理过程tab
            this.showinstr = false
            // this.showinfo = false
            this.showDetail = true
            this.$refs.loadInitPro.loadPage(this.id)
            // location.reload()
          }
        }
      }
    }
</script>

<style scoped>

</style>
