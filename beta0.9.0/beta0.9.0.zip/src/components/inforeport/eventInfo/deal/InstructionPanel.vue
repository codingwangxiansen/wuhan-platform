<!-- 转办列表显示控件控件	 -->
<template>
  <div class="transList">
    <group :title="title"  class="deal gs-credit-card">
      <i class="icon" @click.prevent="transShow = !transShow" :class="transShow ? 'gs-keyboard_arrow_down' : 'gs-keyboard_arrow_up' "></i>
      <!--<panel header=""  :list="list" type="4" ></panel>-->
      <div class="contenBig" v-show="transShow">
        <div class="transContent" v-for="(item, index) in list" :key="index">
          <h3>
            <i  class="gs-user-circle"></i>
            <span :class="userId === item.desc? 'hightLight': ''">{{item.desc}}</span>
            <span class="time pull-right">{{item.date}}</span>
          </h3>
          <p class="transMsg">{{item.title}}</p>
          <p class="transP" :class="userId === item.recvPersonNames? 'hightLight': ''">报送至： <span :class="userId === item.recvPersonNames? 'hightLight': ''">{{item.recvPersonNames}}</span></p>
        </div>
      </div>
    </group>
  </div>
</template>
<style lang="less" scpoed>
  .transList {
    .contenBig {
      padding: 10px;
      .transContent {
        background: #f8f8f8;
        border-top: 1px solid #f8f8f8;
        border-bottom: 1px solid #e2e2e2;
        padding: 5px;
        border-radius: 5px;
        margin-bottom: 5px;
        h3 {
          font-size: 14px;
          line-height: 30px;
        }
        .transMsg {
          border-bottom: 1px dotted #e2e2e2;
          line-height: 20px;
        }
        .transP {
          color: #888;
        }
        .time {
          float: right;
          font-weight: 400;
          font-size: 12px;
        }
      }
    }
    p {
      font-size: 14px;
      line-height: 30px;
    }
  }
</style>
<script>
  import { Cell, Popup, Panel, Group } from 'vux'

  export default {
    props: ['data', 'userId'],
    data() {
      return {
        transShow: false
      }
    },
    components: {
      Cell,
      Popup,
      Panel,
      Group
    },
    computed: {
      // 与父组件通信用属性
      title: {
        get() {
          const expend = this.show ? '' : ''
          return `拟办意见${expend}`
        }
      },
      list: {
        get() {
          const result = []
          this.data.forEach((value) => {
            result.push({
              title: value.disposeDescription,
              desc: value.disposePersonName,
              date: value.disposeTimeStr,
              recvOrgNames: value.recvOrgNames,
              recvPersonNames: value.recvPersonNames
            })
          })
          return result
        }
      }
    },
    methods: {

    },
    mounted() {
    }

  }
</script>
