<!-- 拟办提交组件	 -->
<template>
	<popup v-model="show" class="popContainer">
    	<div class="head">
        <span class="headBtnL" @click="cancel">取消</span>
        <div class="headTitle"></div>
        <span class="headBtnR"   @click="commit">✔ 确定</span>
      </div>
      <box gap="10px 10px" class="transContent">
        	<div class="popup0">
            <!--
            <group class="selectActive">
              <checklist ref="checkList" :max="1" :options="activeArr" v-model="trunTo"></checklist>
            </group>
            -->
            <group>
              <org-check-list ref="orgSel" v-model="targets" label="接收单位"
                              :maxLength="20"></org-check-list>
              <!--
              <cell title="接收人员" :value="userNames" @click.native="chooseUser" is-link></cell>
              -->
            </group>
            <group title="图片上传">
              <img-upload :localIds="localIds" :serverIds="serverIds" :imgMaxSum="imgMaxSum"
                          @on-choose="chooseImg"@on-delete="deleteImg"></img-upload>
            </group>
            <group title="备注">
              <x-textarea :rows="3" v-model="comment" :max="500" placeholder="请输入备注"></x-textarea>
            </group>
        	</div>
      	</box>
    </popup>
</template>
<style lang="less" scoped>
  .transContent {
    height: 85%;
    overflow: scroll;
  }
  .popContainer {
    height:70% !important;
  }
 .head {
   color: #444;
   background-color: #f2f2f2;
   text-align: center;
   font-weight: 500;
   line-height: 45px;
   font-size: 16px;
   z-index: 99;
   span {
     font-size: 14px;
   }
  }
  .headTitle {
    display: inline-block;
  }
  .headBtnL {
    float: left;
    color: #a5a4a4;
    font-weight: normal;
    padding: 0 1em;
  }

  .headBtnR{
    float: right;
    color: #0faaff;
    font-weight: normal;
    padding: 0 1em;

  }
</style>
<script>
import { Box, Popup, Group, Cell, XButton, XTextarea, Checklist } from 'vux'
import OrgCheckList from '../../commoncompents/OrgCheckList'
import LeaderSelector from '../../../gsafetycomponents/LeaderSelector'
import ImgUpload from '../../../mycomponents/ImgUpload'

export default {
  name: 'EventTrans',
  props: ['value', 'type'],
  data() {
    return {
      targets: [],
      localIds: [],
      serverIds: [],
      comment: '',
      imgMaxSum: '3',
      activeArr: [{ key: '5', value: '转办' }, { key: '6', value: '督办' }],
      leaderType: '3'
    }
  },
  computed: {
    trunTo: {
      get() {
        const arr = []
        arr.push(this.type)
        return arr
      },
      set() {
      }
    },
    members: { // 领导ID数组
      get() {
        return this.$store.state.leaderList
      },
      set() {
      }
    },
    userNames() {
      let leaderList
      if (this.leaderType === '1') {
        leaderList = this.$store.state.groupLeader
      } else if (this.leaderType === '2') {
        leaderList = this.$store.state.cityLeader
      } else {
        leaderList = this.$store.state.allUser
      }
      let text = ''
      const o = this.members[0]
      leaderList.forEach(({ key, value }) => {
        if (key === o) {
          text = value
          if (this.members.length > 1) {
            text = `${text}等${this.members.length}人`
          }
        }
      })
      return text
    },
    show: {
      get() {
        return this.value
      },
      set(val) {
        this.$emit('input', val)
      }
    }
  },
  watch: {
    show: 'clear'
  },
  components: {
    Box,
    Popup,
    Group,
    Cell,
    XButton,
    OrgCheckList,
    XTextarea,
    LeaderSelector,
    ImgUpload,
    Checklist
  },
    //
  methods: {
    cancel() {
      this.show = false
      this.$store.commit('resetLeaderList')
      this.$store.commit('setDealWindow', '')
    },
    chooseImg() { // 上传图片点击上传
      const vm = this
      const options = {}
      this.$gsafety.chooseImage(options, (res) => {
        if (res) {
          vm.localIds.push(res.url)
          const localImgId = res.url
          let imgSrc
          if (localImgId.indexOf('storage') > -1) {
            const start = localImgId.indexOf('storage')
            imgSrc = localImgId.substring(start + 7, localImgId.length)
          } else {
            imgSrc = localImgId
          }
          const jsonObj = { localId: imgSrc }
          this.$gsafety.uploadImage(jsonObj, (ress) => {
            if (ress.id) {
              vm.serverIds.push(ress.id)
//                vm.alertShow('图片上传成功')
              vm.$vux.toast.text('图片上传成功', 'middle')
            } else {
//                vm.alertShow('上传图片失败')
              vm.$vux.toast.text('上传图片失败', 'middle')
            }
          })
        }
      })
    },
    deleteImg(index) { // 删除图片自定义回调事件
      this.localIds.splice(index, 1)
      this.serverIds.splice(index, 1)
    },
    //
    clear() {
      console.log('tttt')
      this.targets = []
      this.members = []
      this.comment = ''
      this.trunTo = ['5']
      this.localIds = []
      this.serverIds = []
      if (this.$refs.orgSel) {
        this.$refs.orgSel.init()
      }
    },
    commit() {
//        转办5 督办6
      // const active = this.$refs.checkList.getFullValue()[0].value
      const active = '5'
      if (active) {
        this.$emit('on-confirm', this.targets, this.members, this.comment, active)
      } else {
        this.$vux.toast.text('请选择转办督办', 'middle')
      }
//      this.$refs.orgSel.init()
    },
    chooseUser() {
      if (this.trunTo[0] === '5') {
        this.$store.commit('setDealWindow', 'trans')
      } else if (this.trunTo[0] === '6') {
        this.$store.commit('setDealWindow', 'supervise')
      }
      this.$router.push({
        name: 'LeaderSelect',
        params: {
          leaderType: this.leaderType,
          maxLength: 1
        }
      })
    }
  }
}
</script>
