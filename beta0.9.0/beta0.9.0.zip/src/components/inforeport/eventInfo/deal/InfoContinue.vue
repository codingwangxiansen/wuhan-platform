<!-- 拟办提交组件	 -->
<template>
  <popup v-model="show" class="popContainer">
    <div class="head">
      <span class="headBtnL" @click="cancel">取消</span>
      <div class="headTitle">信息续报</div>
      <span class="headBtnR" @click="commit">✔ 发送续报</span>
    </div>
    <box gap="10px 10px" class="transContent">
      <div class="popup0">
        <group>
          <x-textarea :rows="3" v-model="eventDescription" :max="500" placeholder=""></x-textarea>
        </group>
        <group title="图片上传">
          <img-upload :localIds="localIds" :serverIds="serverIds" :imgMaxSum="imgMaxSum"
                      @on-choose="chooseImg" @on-delete="deleteImg"></img-upload>
        </group>
      </div>
    </box>
  </popup>
</template>
<style lang="less" scoped>
  .transContent {
    height: 80%;
    overflow: scroll;
  }

  .popContainer {
    height: 45% !important;
  }

  .head {
    color: #444;
    background-color: #f2f2f2;
    text-align: center;
    font-weight: 500;
    line-height: 45px;
    font-size: 16px;
    z-index: 99;
    span {
      font-size: 14px;
    }
  }

  .headTitle {
    display: inline-block;
  }

  .headBtnL {
    float: left;
    color: #a5a4a4;
    font-weight: normal;
    padding: 0 1em;
  }

  .headBtnR {
    float: right;
    color: #0faaff;
    font-weight: normal;
    padding: 0 1em;

  }
</style>
<script>
  import { Box, Popup, Group, Cell, XButton, XTextarea, Checklist } from 'vux'
  import { siteUrl } from '../../../../utils/common'
  import OrgCheckList from '../../commoncompents/OrgCheckList'
  import LeaderSelector from '../../../gsafetycomponents/LeaderSelector'
  import ImgUpload from '../../../mycomponents/ImgUpload'

  export default {
    name: 'EventTrans',
    props: ['value', 'type', 'eventInfoId'],
    data() {
      return {
        targets: [],
        localIds: [],
        submitStatus: false,
        serverIds: [],
        eventDescription: '',
        imgMaxSum: '3',
        data: {}
      }
    },
    computed: {
      show: {
        get() {
          return this.value
        },
        set(val) {
          this.$emit('input', val)
        }
      }
    },
    watch: {
      show: 'clear'
    },
    components: {
      Box,
      Popup,
      Group,
      Cell,
      XButton,
      OrgCheckList,
      XTextarea,
      siteUrl,
      LeaderSelector,
      ImgUpload,
      Checklist
    },
    //
    methods: {
      cancel() {
        this.show = false
        this.serverIds = []
        this.eventDescription = ''
        this.$store.commit('setDealWindow', '')
      },
      chooseImg() { // 上传图片点击上传
        const vm = this
        const options = {}
        this.$gsafety.chooseImage(options, (res) => {
          if (res) {
            vm.localIds.push(res.url)
            const localImgId = res.url
            let imgSrc
            if (localImgId.indexOf('storage') > -1) {
              const start = localImgId.indexOf('storage')
              imgSrc = localImgId.substring(start + 7, localImgId.length)
            } else {
              imgSrc = localImgId
            }
            const jsonObj = { localId: imgSrc }
            this.$gsafety.uploadImage(jsonObj, (ress) => {
              if (ress.id) {
                vm.serverIds.push(ress.id)
//                vm.alertShow('图片上传成功')
                vm.$vux.toast.text('图片上传成功', 'middle')
              } else {
//                vm.alertShow('上传图片失败')
                vm.$vux.toast.text('上传图片失败', 'middle')
              }
            })
          }
        })
      },
      deleteImg(index) { // 删除图片自定义回调事件
        this.localIds.splice(index, 1)
        this.serverIds.splice(index, 1)
      },
      //
      clear() {
        console.log('tttt')
        this.targets = []
        this.members = []
        this.comment = ''
        this.trunTo = ['5']
        this.localIds = []
        this.serverIds = []
        if (this.$refs.orgSel) {
          this.$refs.orgSel.init()
        }
      },
      setData() {
        const that = this
        that.data.attachId = this.serverIds
        that.data.eventInfoId = this.eventInfoId
        that.data.eventDescription = this.eventDescription
        return that.data
      },
      commit() {
        const that = this
        const data = that.setData()
        this.validation(data)
        if (this.submitStatus) {
          this.$vux.confirm.show({
            title: '确认保存？',
            content: '',
            onConfirm() {
              const URL = `${siteUrl}/eventInfo/report/agian`
              that.axios.postData(URL, data, (response) => {
                if (response.code === 200) {
                  that.$vux.toast.text('续报成功', 'middle')
                  that.show = false
                  that.$vux.confirm.hide()
                  that.cancel()
                  that.$emit('addContinue')
                } else if (response.message) {
                  that.$vux.toast.text(response.message, 'middle')
                }
              })
            }
          })
        }
      },
      validation(val) {
        if (!val.eventDescription || !val.eventDescription.trim()) {
          this.$vux.toast.text('请输入续报内容', 'middle')
          this.submitStatus = false
          return false
        }
        this.submitStatus = true
        return true
      }
    }
  }
</script>
