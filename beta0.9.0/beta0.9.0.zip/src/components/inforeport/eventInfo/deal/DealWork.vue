<!-- 批示控件	 -->
<template>
  <div class="transList">
    <group title="批示记录" class="deal gs-person2">
      <i class="icon" @click.prevent="tranShow = !tranShow" :class="tranShow ? 'gs-keyboard_arrow_down' : 'gs-keyboard_arrow_up' "></i>
      <div class="bigcontent" v-show="tranShow">
        <div class="widthContent" :style="'width:'+ 11 * list.length +'em;'">
          <div class="workContant" v-for="(item, index) in list" @click="showMore(item.title)">
            <h3><i class="gs-vcard-o"></i><span :class="userId === item.desc? 'hightLight': ''">{{item.desc}}</span></h3>
            <h4>{{item.meta}}</h4>
            <p>{{item.title}}</p>
          </div>
        </div>
      </div>
    </group>
    <x-dialog class="dialog-demo" v-model="showScrollBox">
      <div class="closeDiv" @click="showScrollBox=false">
        <span class="vux-close gs-close-bold"></span>
      </div>
      <!--<p class="dialog-title">Long content</p>-->
      <div class="img-box" >
        <span class="lineCss">{{moreContent}}</span>
      </div>
    </x-dialog>
  </div>
</template>
<style lang="less" scpoed>
  .transList {
    .bigcontent {
      overflow: scroll;
    }
    .dialog-demo {
      .weui-mask {
      }
      .closeDiv {
        width: 30px;
        height: 30px;
        margin-left: 89%;
        border-radius: 50px;
        border-color: #dbd4d4;
        cursor:pointer;
      }
      .lineCss {
        word-wrap: break-word;
        font-size: 14px;
      }
      .img-box {
        height:200px;
        padding: 15px 17px;
        overflow:scroll;
        text-align: left;
      }
    }
    .workContant {
      display: inline-block;
      width: 9em;
      border: 1px solid #e2e2e2;
      margin: 0.5em;
      border-radius: 5px;
      padding: 6px;
      vertical-align: text-top;
      height: 150px;
      h3 {
        font-size: 16px;
        text-align: center;
      }
      h4 {
        font-size: 12px;
        text-align: center;
      }
      p {
        font-size: 12px;
        text-align: left;
        color: #676767;
        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 4;
        overflow: hidden;
        line-height: 24px;
      }
    }
    .time {
      text-align: right;
    }
  }
</style>
<script>
  import { Cell, Popup, Panel, Group, XDialog } from 'vux'

  export default {
    props: ['listDeal', 'userId'],
    data() {
      return {
        tranShow: false,
        showScrollBox: false,
        moreContent: ''
      }
    },
    components: {
      Cell,
      Popup,
      Panel,
      Group,
      XDialog
    },
    created() {
    },
    methods: {
      showMore(content) {
        this.moreContent = content
        this.showScrollBox = true
      }
    },
    computed: {
      list: {
        get() {
          const result = []
          this.listDeal.forEach(({ disposePersonName, disposeDescription, disposeTimeStr }) => {
            result.push({
              title: disposeDescription,
              desc: disposePersonName,
              meta: disposeTimeStr
            })
          })
          return result
        }
      }
    },
    mounted() {
    }

  }
</script>
