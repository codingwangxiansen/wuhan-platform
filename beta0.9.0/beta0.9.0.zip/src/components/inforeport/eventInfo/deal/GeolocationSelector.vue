<!--
地图坐标拾取组件
默认从上一个界面读取坐标参数到该界面上

-->
<template>
	<div>
		<div id="mapDiv">
      <vue-map-search
        :x="x"
        :y="y"
        appkey="8a7b9aac0db21f9dd995e61a14685f05"
        :ssl="true"
        :searchExtent="searchExtent"
        :xyChange="whenChange">
      </vue-map-search>
    </div>
		<group>
			<!--
			<p>坐标[{{lat}}][{{lng}}]</p>
			-->
		  <box  class="positionBtn" v-show="isEdit">
        <x-textarea placeholder="请输入具体位置信息" ref="addrArea" v-model='address'></x-textarea>
		  	<x-button type="theme" class="button" @click.native="closeMap">确定</x-button>
		  </box>

    </group>
	</div>
</template>
<style lang="less" scoped>
  #mapDiv{
    width: 100%;
    height: 413px;
  }
  .positionBtn {
    position: fixed;
    bottom: 0;
    width: 100%;
    background: #ededed;
    z-index: 99;
  }
</style>
<script>
import { Box, Group, XButton, XTextarea } from 'vux'
import Vue from 'vue'
import vueMapSearch from 'vue-map-search'
import config from 'src/config'

Vue.use(vueMapSearch)

export default {
  name: 'GeolocationSelector',
  data() {
    return {
      appKey: config.mapKey,
      x: 114.296350,
      y: 30.595510,
      searchExtent: [110.58838, 29.25286, 118.09204, 31.98012],
      isEdit: true,
      address: '',
      centerLocation: { // 地图中心点位置
        x: 114.296350, // 经度
        y: 30.595510
      }
    }
  },
  created() {
  },
  computed: {
  },
  beforeRouteEnter(to, from, next) {
    next((vm) => {
      vm.x = vm.$store.state.gisLocation.x
      vm.y = vm.$store.state.gisLocation.y
      vm.searchExtent = vm.$store.state.gisLocation.searchExtent
      console.log(vm.$store.state.gisLocation.isEdit)
      console.log('vm.$store.state.gisLocation.isEdit')
      vm.isEdit = vm.$store.state.gisLocation.isEdit
      vm.address = vm.$store.state.gisLocation.address
      if (from.name === 'AddInfo') {
        vm.$store.commit('setIsRefresh', false)
      }
    }
    )
  },
  mounted() {
  },
  components: {
    Box,
    Group,
    XButton,
    XTextarea
  },
  methods: {
    // 关闭组件
    closeMap() {
      const gisLocation = {
        x: this.x,
        y: this.y,
        address: this.address
      }
      this.$store.commit('setGisLocation', gisLocation)
      this.$router.go(-1)
    },
    whenChange(res) {
      if (res.type === 'success') {
        this.x = Number(res.coordinate.x)
        this.y = Number(res.coordinate.y)
        if (res.opts && res.opts.address) {
          this.address = res.opts.address
        }
      } else if (res.type === 'center') {
        this.centerLocation.x = Number(res.coordinate.x)
        this.centerLocation.y = Number(res.coordinate.y)
      } else if (res.type === 'error') {
        this.$vux.toast.text('无法查到当前位置地名，请手动输入!', 'middle')
        this.x = this.centerLocation.x
        this.y = this.centerLocation.y
        this.address = ''
        this.$refs.addrArea.focus()
      }
    }
  }
}
</script>
