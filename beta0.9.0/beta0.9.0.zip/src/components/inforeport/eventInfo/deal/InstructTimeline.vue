<template>
	<div class="timeline-demo">
		<timeline>
			<timeline-item v-for=" (item,index) in list" :key="index">
        <div @click="showMore(item.operDescription)" class="timeline-Style">
          <b>{{item.operName}}</b>
          <h4>
            <span class="fromP">{{item.operUserName}}</span>
            <span class="time" :class="index == 0 ? 'blo' : 'dis'">{{item.operTimeStr}}</span>
          </h4>
          <h4 class="recent">{{item.operDescription}} </h4>
        </div>
			</timeline-item>
        <x-dialog v-model="showScrollBox" class="dialog-demo">
          <div @click="showScrollBox=false" class="closeDiv">
            <span class="vux-close gs-close-bold"></span>
          </div>
          <!--<p class="dialog-title">Long content</p>-->
          <div class="img-box">
            <span class="lineCss">{{getDisposeDescription}}</span>
          </div>
        </x-dialog>
		</timeline>

    <div v-show="list.length == 0" class="tipShow">
      当前页面暂无数据
    </div>
    <div class="loading" v-show="Loaded">
      <img src="../../../../assets/image/eventInfo/index/loading.gif" alt="">
    </div>
	</div>
</template>
<style lang="less" scoped>
  .timeline-demo {
    .time {
      float: right;
      font-size: 12px;
    }
    .fromP {
      color: #000;
    }
  }
  .loading {
    height: 46em;
    position: relative;
    background: #fff;
    overflow: hidden;
  }
  .loading img {
    width: 10%;
    margin: 50% auto 0 auto;
    display: block;
  }
  .personH {
    color: #444;
    margin-right: 0.3em;
    font-size: 1em;
  }
  .timeline-demo p.blo {
    font-size: 12px;
    position: absolute;
    top: 0px;
    right: 0;

  }
  .timeline-demo p.dis {
    font-size: 12px;
    color: #a6a7a7;
    position: absolute;
    top: 0px;
    right: 0;

    /*color: #000;*/
  }
  .timeline-demo .recent {
    color:#666;
    overflow: hidden;/*超出部分隐藏*/
    white-space: nowrap;/*不换行*/
    text-overflow:ellipsis;/*超出部分文字以...显示*/
    font-size: 14px;
  }
  .tipShow{
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translateX(-50%) translateY(-50%);
    font-size: 20px;
    color: #aba8a8;
  }
  .timeline-demo {
    background: #fff;
  }
  .timeline-demo > b {
    color: #0388ff;
  }

  /*timeline STYLE 20180403 ADD*/
  .timeline-Style{
    font-size: 14px;
  }
  h4.recent {
    line-height: 1.2em;
  }
  .closeDiv {
    width: 30px;
    height: 30px;
    margin-left: 89%;
    margin-top: 5px;
    color: #888;
    cursor: pointer;
    cursor:pointer;
  }
  .img-box {
    height:200px;
    padding: 5px 15px 15px 15px;
    overflow:scroll;
    text-align: left;
  }
  .lineCss {
    word-wrap: break-word;
    font-size: 14px;
  }

</style>
<script>
import { Timeline, TimelineItem, XDialog } from 'vux'
import { siteUrl } from '../../../../utils/common'

export default {
  name: 'InstructTimeline',
  props: ['infoId'],
  components: {
    Timeline,
    TimelineItem,
    XDialog
  },
  data() {
    return {
      list: [],
      Loaded: false,
      showScrollBox: false,
      getDisposeDescription: ''
    }
  },
  created() {
    this.init()
  },
  methods: {
    showMore(value) {
      this.getDisposeDescription = value
      this.showScrollBox = true
    },
      // 初始化数据
    init() {
      // const url = `${siteUrl}/eventInfo/handlelog/list-by-eventid/${this.infoId}`
      const url = `${siteUrl}/eventInfo/handlelog/list-by-eventid/${this.infoId}`
      const that = this
      this.$http.get(url).then((res) => {
        that.list = []
        if (res.body.code !== 200) {
          return
        }
        const commonList = res.body.response
        if (commonList.length < 1) {
          return
        }
        if (commonList) {
          const tmpArr = Object.values(commonList)
          tmpArr.forEach((tmp) => {
            that.list.push({
              id: tmp.progressId,
              operUserName: tmp.operUserName,
              operName: tmp.operName,
              operDescription: tmp.operDescription,
              operTimeStr: tmp.operTimeStr
            })
          })
        }
      })
    }
  }
}
</script>

<style lang="less">
.timeline-demo {
	p {
		color: #888;
		font-size: 0.8rem;
	}
	h4 {
		color: #666;
		font-weight: normal;
	}
	.recent {
		color: rgb(4, 190, 2)
	}
}
</style>
