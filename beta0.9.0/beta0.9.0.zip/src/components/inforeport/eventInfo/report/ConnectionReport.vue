<template>
<div class="main">
  <ul>
    <li v-for="(item,index) in list"
        :key="index"
        @click="openDetail(item)">
        <div class="tit">{{item.distName}}-{{item.infoAddress}}-{{item.infoTitle}}</div>
        <div class="clear-float tip">
          <div class="left">{{item.reportOrgName}}  {{item.reportPerson}}</div>
          <div class="right"><i class="gs-exchange icon-mar"></i>关联{{index+1}}</div>
        </div>
        <div class="clear-float footer">
          <div class="left">
            <span class="report">报</span>
            <span >{{item.reportDateStr}}</span>
          </div>
          <div class="right mar">
            <span>{{item.reportPersonPhone}}</span>
          </div>
        </div>
      </li>
  </ul>
</div>
</template>
<style lang="less" scoped>
  ul,li{
    list-style: none;
  }
  ul{
    width:90%;
    margin:0 auto;
  }
  li{
    padding:2% 0 2% 2%;
    border-bottom: 1px dashed #e4e4e4;
  }
  span{
    display: inline-block;
  }
  .left{
    float:left;
  }
  .right{
    float: right;
  }
  .main{
    background-color: #ffffff;
  }
  .tip{
    font-size: 0.9em;
    font-weight: bold;
    margin: 2% 0;
  }
  .report{
    width: 1.5em;
    line-height: 1.5em;
    text-align: center;
    background-color: #03a9f4;
    border-radius: 50%;
    font-size: 0.9em;
    color:#fff;
  }
  .footer{
    font-size: 0.9em;
    height: 1.5em;
    line-height: 1.5em;
    color:#333333;
  }
  .mar{
    margin-right: 17%;
  }
  .icon-mar{
    margin-right:0.1em;
  }
</style>
<script>
  import config from 'src/config'

  export default {
    name: 'ConnectionReport',
    // 数据模型
    data() {
      return {
        value: '',
        currentUser: {},
        infos: {},
        id: '',
        list: []
      }
    },
    beforeRouteEnter(to, from, next) {
      next((vm) => {
        vm.$store.commit('setHeaderTitle', '关联接报') // 设置头部文字
        vm.id = vm.$router.history.current.params.id
        vm.getListItem(vm.id)
      })
    },
    // 组件
    components: { },
    // 页面加载
    created() {
      this.id = this.$router.history.current.params.id
      this.currentUser = this.$store.state.user
      this.getListItem(this.id)
    },
    // 方法
    methods: {
      // 模糊查询
      getListItem(id) {
        this.$store.dispatch('showPageLoading')
        const URL = `${config.siteUrl}/eventInfo/list/sendRelevanceSearch/${id}`
        const that = this
        const param = {
          keyWord: that.value
        }
        that.axios.post(URL, param)
          .then((response) => {
            that.list = []
            const infos = response.data.response.result
            if (infos) {
              const infosValArr = Object.values(infos)
              infosValArr.forEach((value) => {
                that.list.push(value)
              })
            }
            if (infos.attachs) {
              console.log(infos.attachs)
              that.attachs = JSON.parse(infos.attachs)
            }
            that.$store.dispatch('hidePageLoading')
          })
          .catch(() => {

          })
      },
      openDetail(item) {
        const id = item.eventInfoId
        const r = `/report/infoDetails/${id}`
        this.$store.dispatch('showPageLoading')
        this.$router.push(r)
      }
    }
  }
</script>
