<template>
  <div class="add-round">
    <form @submit.prevent="submit" id="multiForm">
      <group title="基本信息" titleColor="" class="ma-bottom">
        <x-input title="信息标题:" placeholder="例：某区发生火灾0人死亡0人受伤" :max="36" v-model='data.infoTitle' :show-clear="false" text-align="left"></x-input>
        <!-- <popup-picker class="addr" title="事发地区:"  placeholder="必填" :data="addressList" v-model="addressArr"></popup-picker> -->
        <cell class="thingType" :value="data.distName"  title="事发地区:" @click.native="chooseDistrict()"></cell>
        <cell title="位置定位:" class="thingAddress gs-location" :value="shortAddress" @click.native="openGeolocationSelector"></cell>
        <!--
        <cell :title="'地理位置'" :value="data.infoAddress" @click.native="$router.push('/deal/GeolocationSelector')"></cell>
        -->
        <!--<x-input title="经度:" v-model='data.longitude' :show-clear="false"></x-input>
        <x-input title="纬度:" v-model='data.latitude' :show-clear="false"></x-input>-->
        <cell class="thingType" :value="data.eventTypeName"  title="事件类型:" @click.native="chooseEventType()"></cell>
        <popup-picker class="thingLevel" title="事件等级:" placeholder="必填" :data="levelList" v-model="levelArr"></popup-picker>
        <!--<x-switch title="是否敏感:" v-model="isSensitive"></x-switch>-->
        <datetime v-model="data.incidentDateStr" placeholder="必填" :min-year=2000
                  format="YYYY-MM-DD HH:mm" title="事发时间:"
                  year-row="{value}年" month-row="{value}月" day-row="{value}日" hour-row="{value}点"
                  minute-row="{value}分" confirm-text="完成" cancel-text="取消"></datetime>
        <!--<datetime v-model="上报时间" placeholder="必填"
                  format="YYYY-MM-DD HH:mm" title="上报时间:"
                  ></datetime>-->
        <x-input title="上报时间:" class="reportTime" v-model='nowTime' :show-clear="false" text-align="left" :readonly="true"></x-input>

        <!--
        <div class="sub-title">情况描述:</div>
        <x-textarea v-model="data.eventDescription" :rows="2" :max="200"></x-textarea>
        -->
        <!--
        <div class="sub-title">采取措施:</div>
        <x-textarea v-model="data.eventMeasures" :rows="2" :max="100"></x-textarea>
        -->
      </group>
      <group title="情况描述">
        <x-textarea  v-model="data.eventDescription" :max="500" :rows="5" placeholder="情况描述(必填)"></x-textarea>
      </group>
      <group title="图片上传">
        <img-upload
          :localIds="localIds"
          :serverIds="serverIds"
          :imgMaxSum="imgMaxSum"
          @on-choose="chooseImg"
          @on-delete="deleteImg">
        </img-upload>
      </group>
      <div v-show="showAudioPart">
        <group title="语音上传">
          <audio-upload
            :audios="audios"
            @on-choose="chooseAudio"
            @on-delete="deleteAudio">
          </audio-upload>
        </group>
        <group title="视频上传">
          <video-upload
            :videos="videos"
            @on-choose="chooseVideo"
            @on-delete="deleteVideo">
          </video-upload>
        </group>
      </div>
      <group v-show="false" title="补充信息（非必填）" class="fileInfo fileLoad">
        <!--<group   :class="isExpandInfo ? 'gs-caret-down' : 'gs-caret-up' " @click.native="isExpandInfo = !isExpandInfo"></group>-->
        <span @click.prevent="isExpandInfo = !isExpandInfo" :class="isExpandInfo ? 'gs-caret-down' : 'gs-caret-up' "></span>
        <div class="loseMain" v-show="isExpandInfo">
          <x-input title="联系电话:" v-model='data.phone' :show-clear="false"></x-input>
          <x-input title="签发领导 :" v-model='data.signLeader' :show-clear="false"></x-input>
          <div class="lose">
            <x-input text-align="left" title="经济损失:" v-model='data.economylose'
                     :show-clear="false"></x-input>
            <span>万元</span>
          </div>
          <div class="lose">
            <x-input text-align="left" title="影响半径:" v-model='data.effectRadius'
                     :show-clear="false"></x-input>
            <span>公里</span>
          </div>
          <div class="lose">
            <x-input text-align="left" title="受伤人数:" v-model='data.woundNum'
                     :show-clear="false"></x-input>
            <span>人</span>
          </div>
          <div class="lose">
            <x-input text-align="left" title="死亡人数:" v-model='data.deathNum'
                     :show-clear="false"></x-input>
            <span>人</span>
          </div>
          <div class="lose">
            <x-input text-align="left" title="失踪人数:" v-model='data.disappearNum'
                     :show-clear="false"></x-input>
            <span>人</span>
          </div>
          <div class="lose">
            <x-input text-align="left" title="受困人数:" v-model='data.lockNum'
                     :show-clear="false"></x-input>
            <span>人</span>
          </div>
          <x-textarea  v-model="data.eventCause" :rows="3" :max="500" placeholder="事件原因:"></x-textarea>
          <x-textarea  v-model="data.eventOrginLost" :rows="3" :max="500" placeholder="损失程度:"></x-textarea>
          <x-textarea  v-model="data.supportReguest" :rows="3" :max="500" placeholder="资源调度:"></x-textarea>
          <x-textarea  v-model="data.remark" :rows="3" :max="500" placeholder="备注:"></x-textarea>
        </div>
      </group>
      <group title="附加信息"  class="unitRep fileLoad" >
        <!--<group   title="上报人信息" :class="isExpandOrg ? 'gs-caret-down' : 'gs-caret-up' " @click.native="isExpandOrg = !isExpandOrg">-->
        <span @click.prevent="isExpandOrg = !isExpandOrg" :class="isExpandOrg ? 'gs-caret-down' : 'gs-caret-up' "></span>
        <div class="add-info" v-show="isExpandOrg">
          <div>
            <x-input title="单位:" readonly v-model='dataUser.orgName' :show-clear="false"></x-input>
            <x-input title="姓名:" readonly v-model='dataUser.username' :show-clear="false"></x-input>
            <x-input title="电话:" readonly v-model="dataUser.tel"></x-input>
          </div>
        </div>
      </group>
      <box class="positionBtn">
        <x-button type="default">保存草稿</x-button>
        <x-button type="theme" @click.native="reportEvent" action-type="button">我要上报</x-button>
      </box>
    </form>
  </div>
</template>

<style lang="less" scoped>

  #multiForm .loseMain {
    background-color: #fff;
  }
  .thingType {
    position:relative;
  &:before {
     content: " ";
     position: absolute;
     top: 0;
     width: 92%;
     height: 1px;
     border-top: 1px solid #D9D9D9;
     color: #D9D9D9;
     -webkit-transform-origin: 0 0;
     transform-origin: 0 0;
     -webkit-transform: scaleY(0.5);
     transform: scaleY(0.5);
     left: 15px;
   }
  }
  #multiForm .unitRep {
    margin-bottom: 4em;
  .gs-caret-down:before , .gs-caret-up:before{
    position: absolute;
    top: 0em;
    right: 0.5em;
    z-index: 1;
    font-size: 30px;
    color: #ddd;
  }
  .add-info {
    background-color: #fff;
  }
  }
  .positionBtn {
    position: fixed;
    bottom: 0;
    width: 95%;
    background: #ededed;
    padding: 10px;
    z-index: 99;
  }
  #multiForm .vux-popup-picker-select , .weui-input{
    text-align:right;
  }
  .ma-bottom .weui-input{
    box-sizing: border-box;
    padding-right: 1em;
  }
  .cellLose .weui-input{
    box-sizing: border-box;
    padding-right: 3em;
  }
  #multiForm .img-box {
    margin: 10px 0 0 10px;
  }

  .weui-label {
    width: 5.5em !important;
  }
  .weui-cell p {

  }
  div.lose {

    position: relative;
  }
  div.lose span {
    position: absolute;
    top: 0.6em;
    right: 1em;
  }
  div.lose .vux-x-input:after , .sub-title:after {
    content: " ";
    position: absolute;
    top: 0;
    width: 92%;
    height: 1px;
    border-top: 1px solid #D9D9D9;
    color: #D9D9D9;
    -webkit-transform-origin: 0 0;
    transform-origin: 0 0;
    -webkit-transform: scaleY(0.5);
    transform: scaleY(0.5);
    left: 15px;
  }
  .sub-title {
    padding: 10px 25px;
    position: relative;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
  }

  .square-o span:first-child {
    margin-left: 7px;
  }
  .add-round {
    background: #EDEDED;
  }

  .ma-bottom {
    overflow: hidden;
  }
  .weui-cells .weui-cell_access .weui-cell__ft {
    text-align: right;
    padding-right: 1em;
  }
  #multiForm .weui-cells__title{
    background: transparent;
    color: #666;
    font-size: 1em;
    text-align: left;
    padding-left: 1.5em;
    margin: 0.5em 0;
  }

  #multiForm .square-o{
    background: #C0DEED;
    margin: 0;
    line-height: 40px;
    color: #fff;
    font-size: 16px;
    padding: 0px 10px;
    text-align: left;
  }
  #multiForm .weui-cell::before {
    content: " ";
    position: absolute;
    top: 0;
    width: 92%;
    height: 1px;
    border-top: 1px solid #D9D9D9;
    color: #D9D9D9;
    -webkit-transform-origin: 0 0;
    transform-origin: 0 0;
    -webkit-transform: scaleY(0.5);
    transform: scaleY(0.5);
    left: 15px;
  }
  .vux-cell-box:not(:first-child):before {
    width: 92% !important;
  }
  .vux-x-input:not(:first-child):after ,.vux-datetime:not(:first-child):after {
    content: " ";
    position: absolute;
    top: 0;
    width: 92%;
    height: 1px;
    border-top: 1px solid #D9D9D9;
    color: #D9D9D9;
    -webkit-transform-origin: 0 0;
    transform-origin: 0 0;
    -webkit-transform: scaleY(0.5);
    transform: scaleY(0.5);
    left: 15px;
  }
  #multiForm .vux-x-textarea:before{
    content: " ";
    position: absolute;
    left: 0;
    top: 0;
    right: 0;
    height: 1px;
    border-top: 1px solid #D9D9D9;
    color: #D9D9D9;
    -webkit-transform-origin: 0 0;
    transform-origin: 0 0;
    -webkit-transform: scaleY(0.5);
    transform: scaleY(0.5);
  }

  #multiForm .vux-x-textarea:after{
    content: " ";
    position: absolute;
    left: 0;
    bottom: 0;
    right: 0;
    height: 1px;
    border-bottom: 1px solid #D9D9D9;
    color: #D9D9D9;
    -webkit-transform-origin: 0 100%;
    transform-origin: 0 100%;
    -webkit-transform: scaleY(0.5);
    transform: scaleY(0.5);
  }
</style>
<script>
  import {
    XInput,
    XTextarea,
    XAddress,
    PopupPicker,
    Group,
    Cell,
    Selector,
    Datetime,
    ChinaAddressData,
    XButton,
    XSwitch,
    Box
  } from 'vux'
  import Vue from 'vue'
  import VueResource from 'vue-resource'
  import { siteUrl } from '../../../../utils/common'
  import ImgUpload from '../../../mycomponents/ImgUpload'
  import VideoUpload from '../../../mycomponents/VideoUpload'// 视频上传组件
  import AudioUpload from '../../../mycomponents/AudioUpload'// 语音上传组件
  import EventTypeCell from '../../../gsafetycomponents/EventTypeCell'

  // 启用请求组件
  Vue.use(VueResource)

  export default {
    name: 'AddInfo',
    // 数据模型
    data() {
      return {
        scrollTop: 0,
        userTel: '',
        nowTime: '',
        isSensitive: false,
        submitStatus: false,
        orgClass: 'gs-plus-square-o',
        otherClass: 'gs-plus-square-o',
        data: {},
        dataUser: {
          orgUser: {
            username: ''
          }
        },
        saveUrl: '',
        isExpandOrg: false,
        isExpandInfo: false,
        addressArr: [],
        levelArr: [],
        imgMaxSum: '3',
        showAudioPart: true,
        localIds: [],
        serverIds: [],
        audios: [],
        videos: [],
        loadingShow: false,
        loadText: '',
        levelList: [['一般', '较大', '重大', '特别重大']],
        addressList: [['江岸区', '江汉区', '硚口区', '汉阳区', '武昌区', '青山区(化工区)', '洪山区', '蔡甸区', '江夏区', '东西湖区', '黄陂区', '新洲区', '东湖开发区', '武汉经济开发区(汉南区)', '东湖风景区', '武汉新港', '长江新城']],
        level: [{ code: '1', name: '特别重大' }, { code: '2', name: '重大' }, { code: '3', name: '较大' }, {
          code: '4',
          name: '一般'
        }, { code: '5', name: '其它' }],
        address: [
          { code: '420102', name: '江岸区' },
          { code: '420103', name: '江汉区' },
          { code: '420104', name: '硚口区' },
          { code: '420105', name: '汉阳区' },
          { code: '420106', name: '武昌区' },
          { code: '420107', name: '青山区(化工区)' },
          { code: '420111', name: '洪山区' },
          { code: '420114', name: '蔡甸区' },
          { code: '420115', name: '江夏区' },
          { code: '420112', name: '东西湖区' },
          { code: '420116', name: '黄陂区' },
          { code: '420117', name: '新洲区' },
          { code: '420118', name: '东湖开发区' },
          { code: '420113', name: '武汉经济开发区(汉南区)' },
          { code: '420119', name: '东湖风景区' },
          { code: '420120', name: '武汉新港' },
          { code: '420121', name: '长江新城' }
        ],
        type: [{ code: '11000', name: '自然灾害' }, { code: '12000', name: '事故灾难' }, {
          code: '13000',
          name: '公共卫生事件'
        }, { code: '14000', name: '社会安全事件' }, { code: '10000', name: '突发事件' }]
      }
    },
    // 组件
    components: {
      XInput,
      XTextarea,
      XAddress,
      PopupPicker,
      ChinaAddressData,
      Group,
      Cell,
      Selector,
      Datetime,
      XButton,
      XSwitch,
      Box,
      ImgUpload,
      AudioUpload,
      VideoUpload,
      EventTypeCell
    },

    computed: {
      // 与父组件通信用属性
      shortAddress: {
        get() {
          if (this.data.infoAddress) {
            return `${this.data.infoAddress.substring(0, 14)}...`
          }
          return '请选择位置'
        }
      }
    },
    beforeRouteEnter(to, from, next) {
      next((vm) => {
        vm.$store.commit('setHeaderTitle', '新增突发事件信息')  // 设置头部文字
        vm.nowTime = vm.getTime()
        if (vm.$store.state.projectType === 'mini') {
          vm.showAudioPart = false
        }
        if (from.name) {
          if (from.name === 'eventTypeSelect') {
            const eventType = vm.$store.state.chooseEventType
            vm.$set(vm.data, 'eventTypeName', eventType.name)
            vm.data.eventType = eventType.code
            vm.data.eventTypeName = eventType.name
          } else if (from.name === 'districtSelector') {
            const district = vm.$store.state.chooseDistrict
            vm.$set(vm.data, 'distName', district.name)
            vm.$set(vm.data, 'distCode', district.code)
          } else if (from.name === 'GeolocationSelector') {
            if (vm.$store.state.gisLocation) {
              vm.$set(vm.data, 'infoAddress', vm.$store.state.gisLocation.address) // 修改对象里面的数据
              vm.data.latitude = vm.$store.state.gisLocation.x
              vm.data.longitude = vm.$store.state.gisLocation.y
              vm.$store.commit('resetGisLocation')
            }
          } else {
            vm.init()
            vm.$store.commit('resetGisLocation') // 重置全局地理位置信息
          }
        } else {
          vm.init()
          vm.$store.commit('resetGisLocation') // 重置全局地理位置信息
        }
      })
    },
    // vue实例挂着后调用
    mounted() {

    },
    created() {
      this.dataUser = this.$store.state.user
    },
    watch: {
    },
    // 定义方法区
    methods: {
      //  打开选择事件类型页面
      chooseEventType() {
        let code
        if (this.data.eventType) {
          code = this.data.eventType
        } else {
          code = ''
        }
        this.$store.commit('setChooseEventType', {
          code,
          name: this.data.eventTypeName ? this.data.eventTypeName : ''
        })
        this.$router.push({
          name: 'eventTypeSelect',
          params: {
            code
          }
        })
      },
      chooseDistrict() {
        let code
        if (this.data.distCode) {
          code = this.data.distCode
        } else {
          code = ''
        }
        this.$store.commit('setChooseDistrict', {
          code,
          name: this.data.distName ? this.data.distName : ''
        })
        this.$router.push({
          name: 'districtSelector',
          params: {
            code
          }
        })
      },
//        获取当前时间
      getTime() {
        const date = new Date()
        const seperator1 = '-'
        const year = date.getFullYear()
        let month = date.getMonth() + 1
        let strDate = date.getDate()
        if (month >= 1 && month <= 9) {
          month = `0${month}`
        }
        if (strDate >= 0 && strDate <= 9) {
          strDate = `0${strDate}`
        }
        const hour = date.getHours() < 10 ? `0${date.getHours()}` : date.getHours()
        const minute = date.getMinutes() < 10 ? `0${date.getMinutes()}` : date.getMinutes()
//        const second = date.getSeconds() < 10 ? `0${date.getSeconds()}` : date.getSeconds()
        const currentdate = `${year}${seperator1}${month}${seperator1}${strDate} ${hour}:${minute}`
        return currentdate
      },
      /**
       *初始化页面
       */
      init() {
        // 通过 `vm` 访问组件实例
        this.localIds = []
        this.serverIds = []
        this.addressArr = []
        this.levelArr = ['一般']
        this.saveUrl = `${siteUrl}/eventInfo/save`
        this.data = {}
        this.audios = []
        this.videos = []
      },
      /*
       *打开GeolocationSelector
       */
      openGeolocationSelector() {
        const g = {
          x: this.data.longitude ? this.data.longitude : 114.296350,
          y: this.data.latitude ? this.data.longitude : 30.595510,
          isEdit: true,
          address: this.data.infoAddress
        }
        this.$store.commit('setGisLocation', g)
        this.$router.push('/deal/GeolocationSelector')
      },
      chooseImg() {  // 上传图片点击上传
        const vm = this
        const options = {}
        this.$gsafety.chooseImage(options, (res) => {
          if (res) {
            vm.localIds.push(res.url)
            const localImgId = res.url
            let imgSrc
            if (localImgId.indexOf('storage') > -1) {
              const start = localImgId.indexOf('storage')
              imgSrc = localImgId.substring(start + 7, localImgId.length)
            } else {
              imgSrc = localImgId
            }
            const jsonObj = { localId: imgSrc }
            this.$gsafety.uploadImage(jsonObj, (ress) => {
              if (ress.id) {
                vm.$vux.toast.text('图片上传成功', 'middle')
                vm.serverIds.push(ress.id)
                // vm.alertShow('图片上传成功')
              } else {
                vm.$vux.toast.text('上传图片失败', 'middle')
                // vm.alertShow('上传图片失败')
              }
            })
          }
        })
      },
      deleteImg(index) { // 删除图片自定义回调事件
        this.localIds.splice(index, 1)
        this.serverIds.splice(index, 1)
      },
      chooseAudio() {  // 点击录制音频
        const that = this
        that.$vux.loading.show({
          text: 'Loading'
        })
        this.$gsafety.startVoice(
          (res) => {
            that.audios.push(res)
            that.$vux.loading.hide()
          },
          // 取消
          () => {
            console.log('我上传失败了')
            that.$vux.loading.hide()
          }
        )
      },
      deleteAudio(index) { // 删除视频自定义回调事件
        this.audios.splice(index, 1)
      },
      chooseVideo() {  // 点击录制视频
        const that = this
        that.$vux.loading.show({
          text: 'Loading'
        })
        this.$gsafety.startVideo(
          (res) => {
            that.videos.push(res)
            that.$vux.loading.hide()
          },
          // 取消
          () => {
            that.$vux.loading.hide()
          }
        )
      },
      deleteVideo(index) {  // 删除视频自定义回调事件
        this.videos.splice(index, 1)
      },
      setData() {
        const that = this

        Array.from(this.address, (x) => {
          if (x.name === this.addressArr[0]) {
            that.data.distCode = x.code
          }
          return false
        })

        Array.from(this.level, (x) => {
          if (x.name === this.levelArr[0]) {
            that.data.eventLevelCode = x.code
          }
          return false
        })
        that.data.attachId = this.serverIds
        // 添加视频附件
        this.videos.forEach((item) => {
          that.data.attachId.push(item.id)
        })
        // 添加音频附件
        this.audios.forEach((item) => {
          that.data.attachId.push(item.id)
        })
        return that.data
      },
      submit() {
        const that = this
        const data = that.setData()
        this.validation(data)
        if (this.submitStatus) {
          this.$vux.confirm.show({
            title: '确认保存？',
            content: '',
            onConfirm() {
              that.$http.post(that.saveUrl, data).then((response) => {
                if (response.body.code === 200) {
                  that.$router.go(-1)
                  // that.alertShow('保存成功')
                  that.$vux.toast.text('保存成功', 'middle')
                  that.$vux.confirm.hide()
                } else if (response.body.message) {
                  that.$vux.toast.text(response.body.message, 'middle')
                  // that.alertShow(response.body.message)
                }
              }, () => {
                // that.alertShow('操作失败')
                that.$vux.toast.text('操作失败', 'middle')
                that.$vux.confirm.hide()
              })
            }
          })
        }
      },
      validation(val) {
        if (!val.infoTitle || !val.infoTitle.trim()) {
          this.$vux.toast.text('请输入信息标题', 'middle')
          // this.alertShow('请输入信息标题')
          this.submitStatus = false
          return false
        } else if (!val.distCode) {
          this.$vux.toast.text('请选择事发地区', 'middle')
          // this.alertShow('请选择事发地区')
          this.submitStatus = false
          return false
        } else if (!val.latitude && !val.longitude) {
          this.$vux.toast.text('请选择位置定位', 'middle')
          // this.alertShow('请选择位置定位')
          this.submitStatus = false
          return false
        } else if (!val.eventType) {
          this.$vux.toast.text('请选择事发类型', 'middle')
          // this.alertShow('请选择事发类型')
          this.submitStatus = false
          return false
        } else if (!val.eventLevelCode) {
          this.$vux.toast.text('请选择事件等级', 'middle')
          // this.alertShow('请选择事件等级')
          this.submitStatus = false
          return false
        } else if (!val.incidentDateStr) {
          this.$vux.toast.text('请选择事发时间', 'middle')
          // this.alertShow('请选择事发时间')
          this.submitStatus = false
          return false
        } else if (!val.eventDescription) {
          this.$vux.toast.text('请输入情况描述', 'middle')
          // this.alertShow('请输入情况描述')
          this.submitStatus = false
          return false
        }
        this.submitStatus = true
        console.log(true)
        return true
      },
      expandOther() {
        this.isExpandInfo = !this.isExpandInfo
        if (this.isExpandInfo) {
          this.otherClass = 'gs-minus-square-o'
        } else {
          this.otherClass = 'gs-plus-square-o'
        }
      },
      expandOrg() {
        this.isExpandOrg = !this.isExpandOrg
        if (this.isExpandOrg) {
          this.orgClass = 'gs-minus-square-o'
        } else {
          this.orgClass = 'gs-plus-square-o'
        }
      },
      //
      reportEvent() {
        const that = this
        const data = this.setData()
        if (!this.validation(this.setData())) return
        const URL = `${siteUrl}/eventInfo/sendsave`
        this.$vux.confirm.show({
          title: '确认上报？',
          content: '',
          onConfirm() {
            that.$http.post(URL, data).then((response) => {
              if (response.body.code === 200) {
                // that.$router.push(`/report/addInfoTarget/${response.body.response.eventInfoId}`)
                const url = `${siteUrl}/eventInfo/sendInfoApply`
                console.log(response)
                that.data.mainObjectId = response.body.response
                that.$http.post(url, that.data).then((res) => {
                  console.log(res)
                  if (res.status === 200) {
                    that.$vux.toast.text('上报成功', 'middle')
                    // that.alertShow('上报成功')
                    that.$router.go(-1)
                  }
                }, () => {
                  that.$vux.confirm.hide()
                  that.$vux.toast.text('操作失败', 'middle')
                  // that.alertShow('操作失败')
                })
              } else {
                that.$vux.toast.text(response.body.message, 'middle')
                // that.alertShow(response.body.message)
              }
            }, () => {
              // that.alertShow('操作失败')
              that.$vux.toast.text('操作失败', 'middle')
              that.$vux.confirm.hide()
            })
          }
        })
      }
    }
  }
</script>
