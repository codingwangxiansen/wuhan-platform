<template>
  <div class="ma-round edit-round">
    <form @submit.prevent="submit" id="multiForm">
      <group title="基本信息" titleColor="" class="ma-bottom">
        <x-input title="信息标题:" placeholder="必填" v-model='data.infoTitle' :show-clear="false" text-align="left" :max="36"></x-input>
        <cell class="thingType" :value="data.distName"  title="事发地区:" @click.native="chooseDistrict()"></cell>
        <!-- <popup-picker class="addr" title="事发地区:"  placeholder="必填" :data="addressList" v-model="addressArr"></popup-picker> -->
        <cell class="local" title="位置定位:" :value="data.infoAddress" @click.native="openGeolocationSelector"></cell>
        <!--<x-input title="经度:" v-model='data.longitude' :show-clear="false"></x-input>
        <x-input title="纬度:" v-model='data.latitude' :show-clear="false"></x-input>-->
        <!-- <event-type-cell :options="{title:'事件类型',placeholder:'请选择事件类型',columns:1}" v-model="data.eventType"></event-type-cell> -->
        <cell class="thingType" :value="data.eventTypeName"  title="事件类型:" @click.native="chooseEventType()"></cell>
        <!--<cell class="local" title="类型"  @click.native="openEventTypeChose"></cell>-->
        <popup-picker title="事件等级:" placeholder="必填" :data="levelList" v-model="levelArr"></popup-picker>
        <datetime v-model="data.incidentDateStr" placeholder="请选择" :min-year=2000
                  format="YYYY-MM-DD HH:mm" title="事发时间:"
                  year-row="{value}年" month-row="{value}月" day-row="{value}日" hour-row="{value}点"
                  minute-row="{value}分" confirm-text="完成" cancel-text="取消"></datetime>
      </group>
      <group title="情况描述">
		 <x-textarea  v-model="data.eventDescription" :rows="3" placeholder="情况描述(必填)"></x-textarea>
      </group>
      <group title="图片上传">
        <img-upload
          :localIds="localIds"
          :serverIds="serverIds"
          :imgMaxSum="imgMaxSum"
          @on-choose="chooseImg"
          @on-delete="deleteImg">
        </img-upload>
      </group>
      <group title="语音上传">
        <audio-upload
          :audios="audios"
          @on-choose="chooseAudio"
          @on-delete="deleteAudio">
        </audio-upload>
      </group>
      <group title="视频上传">
        <video-upload
          :videos="videos"
          @on-choose="chooseVideo"
          @on-delete="deleteVideo">
        </video-upload>
      </group>
      <group title="附加信息" class="unitRep fileLoad">
        <span @click.prevent="isExpandOrg = !isExpandOrg" :class="isExpandOrg ? 'gs-caret-down' : 'gs-caret-up' "></span>
        <div class="add-info">
          <div v-show="isExpandOrg">
            <x-input title="单位:" readonly v-model='dataUser.orgName' :show-clear="false"></x-input>
            <x-input title="姓名:" readonly v-model='dataUser.orgUser.username' :show-clear="false"></x-input>
            <x-input title="电话:" readonly v-model='dataUser.orgUser.mobileTel' :show-clear="false"></x-input>
          </div>
        </div>
      </group>
      <box class="positionBtn">
      	<x-button type="default">保存草稿</x-button>
      	<x-button type="theme" @click.native="reportEvent" action-type="button">我要上报</x-button>
      </box>
    </form>
  </div>
</template>

<style lang="less" scpoed>
  @import "../../../../styles/common.less";
  .local .weui-cell__ft {
    padding-left: 16px;
  }
  #multiForm .weui-input{
    box-sizing: border-box;
    color: #aaacb2;
  }
  #multiForm .img-box {
    margin: 10px 0 0 10px;
  }
  .unitRep{
    margin-bottom: 8em;
  }
  .positionBtn {
    position: fixed;
    bottom: 0;
    width: 95%;
    background: #ededed;
    padding: 10px;
    z-index: 99;
  }
  div.lose {

    position: relative;
  }
  div.lose span {
    position: absolute;
    top: 0.6em;
    right: 1em;
  }
  div.lose .vux-x-input:after , .sub-title:after {
    content: " ";
    position: absolute;
    top: 0;
    width: 92%;
    height: 1px;
    border-top: 1px solid #D9D9D9;
    color: #D9D9D9;
    -webkit-transform-origin: 0 0;
    transform-origin: 0 0;
    -webkit-transform: scaleY(0.5);
    transform: scaleY(0.5);
    left: 15px;
  }
  .weui-label {
    width: 5.5em !important;
  }
  .weui-cell p {

  }
  .sub-title {
    padding: 10px 25px;
    position: relative;
    display: -webkit-box;
    display: -webkit-flex;
    display: flex;
    -webkit-box-align: center;
    -webkit-align-items: center;
    align-items: center;
  }

  .square-o span:first-child {
    margin-left: 7px;
  }


  .ma-round {
    background: #EDEDED;
  }

  .ma-bottom {
    margin-bottom: 15px;
    overflow: hidden;
  }
  #multiForm .square-o{
    background: #C0DEED;
    margin: 0;
    line-height: 40px;
    color: #fff;
    font-size: 16px;
    padding: 0px 10px;
    text-align: left;
  }

  .vux-cell-box:not(:first-child):before {
    width: 92% !important;
  }
  .vux-x-input:not(:first-child):after ,.vux-datetime:not(:first-child):after {
    content: " ";
    position: absolute;
    top: 0;
    width: 92%;
    height: 1px;
    border-top: 1px solid #D9D9D9;
    color: #D9D9D9;
    -webkit-transform-origin: 0 0;
    transform-origin: 0 0;
    -webkit-transform: scaleY(0.5);
    transform: scaleY(0.5);
    left: 15px;
  }
  #multiForm .vux-x-textarea:before{
    content: " ";
    position: absolute;
    left: 0;
    top: 0;
    right: 0;
    height: 1px;
    border-top: 1px solid #D9D9D9;
    color: #D9D9D9;
    -webkit-transform-origin: 0 0;
    transform-origin: 0 0;
    -webkit-transform: scaleY(0.5);
    transform: scaleY(0.5);
  }

  #multiForm .vux-x-textarea:after{
    content: " ";
    position: absolute;
    left: 0;
    bottom: 0;
    right: 0;
    height: 1px;
    border-bottom: 1px solid #D9D9D9;
    color: #D9D9D9;
    -webkit-transform-origin: 0 100%;
    transform-origin: 0 100%;
    -webkit-transform: scaleY(0.5);
    transform: scaleY(0.5);
  }
</style>
<script>
  import {
    ConfirmPlugin,
    XInput,
    XTextarea,
    XAddress,
    PopupPicker,
    Group,
    Cell,
    Selector,
    Datetime,
    ChinaAddressData,
    XButton,
    XSwitch,
    Box
  } from 'vux'
  import Vue from 'vue'
  import VueResource from 'vue-resource'
  import { siteUrl, fileserver } from '../../../../utils/common'
  import ImgUpload from '../../../mycomponents/ImgUpload'
  import EventTypeCell from '../../../gsafetycomponents/EventTypeCell'
  import VideoUpload from '../../../mycomponents/VideoUpload' // 视频上传组件
  import AudioUpload from '../../../mycomponents/AudioUpload' // 语音上传组件

  // 启用请求组件
  Vue.use(VueResource)
  Vue.use(ConfirmPlugin)

  export default {
    // 数据模型
    data() {
      return {
        submitStatus: false,
        orgClass: 'gs-plus-square-o',
        otherClass: 'gs-plus-square-o',
        data: {},
        dataUser: {
          orgUser: {
            username: ''
          }
        },
        audios: [],
        videos: [],
        saveUrl: '',
        isExpandOrg: false,
        isExpandInfo: false,
        addressArr: [],
        levelArr: [],
        imgMaxSum: '3',
        localIds: [],
        serverIds: [],
        loadingShow: false,
        loadText: '',
        levelList: [['特别重大', '重大', '较大', '一般']],
        addressList: [['江岸区', '江汉区', '硚口区', '汉阳区', '武昌区', '青山区', '洪山区', '东西湖区', '汉南区', '蔡甸区', '江夏区', '黄陂区', '新洲区']],
        level: [{ code: '1', name: '特别重大' }, { code: '2', name: '重大' }, { code: '3', name: '较大' }, {
          code: '4',
          name: '一般'
        }, { code: '5', name: '其它' }],
        address: [{ code: '420102', name: '江岸区' }, { code: '420103', name: '江汉区' }, {
          code: '420104',
          name: '硚口区'
        }, { code: '420105', name: '汉阳区' },
          { code: '420106', name: '武昌区' }, { code: '420107', name: '青山区' }, { code: '420111', name: '洪山区' }, {
            code: '420112',
            name: '东西湖区'
          },
          { code: '420113', name: '汉南区' }, { code: '420114', name: '蔡甸区' }, { code: '420115', name: '江夏区' }, {
            code: '420116',
            name: '黄陂区'
          }, { code: '420117', name: '新洲区' }],
        type: [{ code: '11000', name: '自然灾害' }, { code: '12000', name: '事故灾难' }, {
          code: '13000',
          name: '公共卫生事件'
        }, { code: '14000', name: '社会安全事件' }, { code: '10000', name: '突发事件' }]
      }
    },

    // 组件
    components: {
      ConfirmPlugin,
      XInput,
      XTextarea,
      XAddress,
      PopupPicker,
      ChinaAddressData,
      Group,
      Cell,
      Selector,
      Datetime,
      XButton,
      XSwitch,
      Box,
      ImgUpload,
      VideoUpload,
      EventTypeCell,
      AudioUpload
    },
    beforeRouteEnter(to, from, next) {
      next((vm) => {
        console.log('before')
        if (from.name === 'eventTypeSelect') {
          const eventType = vm.$store.state.chooseEventType
          vm.$set(vm.data, 'eventTypeName', eventType.name)
          vm.data.eventType = eventType.code
          vm.data.eventTypeName = eventType.name
        } else if (from.name === 'districtSelector') {
          const district = vm.$store.state.chooseDistrict
          vm.$set(vm.data, 'districtName', district.name)
          vm.data.distCode = district.code
          vm.data.distName = district.name
        } else if (from.name === 'GeolocationSelector') {
          if (vm.$store.state.gisLocation) {
            vm.$set(vm.data, 'infoAddress', vm.$store.state.gisLocation.address) // 修改对象里面的数据
            vm.data.latitude = vm.$store.state.gisLocation.x
            vm.data.longitude = vm.$store.state.gisLocation.y
            vm.$store.commit('resetGisLocation')
          }
        } else {
          // 通过 `vm` 访问组件实例
          vm.$store.commit('setHeaderTitle', '信息登记')  // 设置头部文字
          vm.id = vm.$router.history.current.params.id
          vm.localIds = []
          vm.serverIds = []
          vm.addressArr = []
          vm.levelArr = []
          if (vm.id) {
            // 更新
            vm.data.infoId = vm.id
            vm.getEventBase()
            vm.saveUrl = `${siteUrl}/eventInfo/update`
          }
          console.log('从上个页面返回')
        }
      })
    },
    // vue实例创建后调用
    created() {
    },
    computed: {
    },
    watch: {},
    // 定义方法区
    methods: {
      //  打开选择事件类型页面
      chooseEventType() {
        let code
        if (this.data.eventType) {
          code = this.data.eventType
        } else {
          code = ''
        }
        this.$store.commit('setChooseEventType', {
          code,
          name: this.data.eventTypeName ? this.data.eventTypeName : ''
        })
        this.$router.push({
          name: 'eventTypeSelect',
          params: {
            code
          }
        })
      },
      chooseDistrict() {
        let code
        if (this.data.distCode) {
          code = this.data.distCode
        } else {
          code = ''
        }
        this.$store.commit('setChooseDistrict', {
          code,
          name: this.data.distName ? this.data.distName : ''
        })
        this.$router.push({
          name: 'districtSelector',
          params: {
            code
          }
        })
      },
      chooseImg() {  // 上传图片点击上传
        const vm = this
        const options = {}
        this.$gsafety.chooseImage(options, (res) => {
          if (res) {
            vm.localIds.push(res.url)
            const localImgId = res.url
            const start = localImgId.indexOf('storage')
            const imgSrc = localImgId.substring(start + 7, localImgId.length)
            const jsonObj = { localId: imgSrc }
            this.$gsafety.uploadImage(jsonObj, (resA) => {
              if (resA.id) {
                vm.serverIds.push(resA.id)
                // vm.alertShow(resA.id)
                vm.$vux.toast.text('图片上传成功', 'middle')
              } else {
                // vm.alertShow('上传图片失败')
                vm.$vux.toast.text('上传图片失败', 'middle')
              }
            })
          }
        })
      },
      deleteImg(index) { // 删除图片自定义回调事件
        this.localIds.splice(index, 1)
        this.serverIds.splice(index, 1)
      },
      getEventBase() {
        const that = this
        const URL = `${siteUrl}${this.$REST.EventInfo.VIEW}/${this.id}`
        this.$http.get(URL).then(
          function (response) {
            that.$store.dispatch('hidePageLoading')
            if (response.body.code === 200) {
              this.data = response.body.response
              this.dataUser = {
                orgName: this.data.reportOrgName,
                orgUser: {
                  username: this.data.reportPerson,
                  mobileTel: this.data.reportPersonPhone
                }
              }
              this.addressArr.push(this.data.distName)
              this.levelArr.push(this.data.eventLevelName)
              if (this.data.attachExist) {
                const attachids = JSON.parse(this.data.imgAttach)
                if (attachids) {
                  const valueAttr = Object.values(attachids)
                  valueAttr.forEach((value) => {
                    this.localIds.push(fileserver + value.attachPath)
                    this.serverIds.push(value.id)
                  })
                }
              }
              if (this.data.audioAttach) {
                this.audios = JSON.parse(this.data.audioAttach)
              }
              if (this.data.videoAttach) {
                this.videos = JSON.parse(this.data.videoAttach)
              }
            }
          })
      },
      /* 打开GeolocationSelector */
      openGeolocationSelector() {
        const g = {
          longitude: this.data.longitude,
          latitude: this.data.latitude,
          type: '',
          address: this.data.infoAddress
        }
        this.$store.commit('setGisLocation', g)
        this.$router.push('/deal/GeolocationSelector')
      },
      openEventTypeChose() {
        this.$router.push('/deal/eventTypeChose')
      },
      submit() {
        const that = this
        Array.from(this.address, (x) => {
          if (x.name === this.addressArr[0]) {
            that.data.distCode = x.code
          }
          return false
        })

        Array.from(this.level, (x) => {
          if (x.name === this.levelArr[0]) {
            that.data.eventLevelCode = x.code
          }
          return false
        })
        that.data.attachId = this.serverIds
        this.videos.forEach((item) => {
          that.data.attachId.push(item.id)
        })
        this.audios.forEach((item) => {
          that.data.attachId.push(item.id)
        })
        const data = that.data
        this.validation(data)
        if (this.submitStatus) {
          this.$vux.confirm.show({
            title: '确认保存？',
            content: '',
            onConfirm() {
              that.$http.post(that.saveUrl, data).then((response) => {
                console.log(response)
                if (response.body.code === 200) {
                  that.$router.go(-1)
                  // that.alertShow('保存成功')
                  that.$vux.toast.text('保存成功', 'middle')
                  that.$vux.confirm.hide()
                } else if (response.body.message) {
                  that.alertShow(response.body.message)
                }
              }, () => {
                // that.alertShow('操作失败')
                that.$vux.toast.text('操作失败', 'middle')
                that.$vux.confirm.hide()
              })
            }
          })
        }
      },
      validation() {
        this.submitStatus = true
      },
      chooseAudio() {  // 点击录制视频
        const that = this
        that.$vux.loading.show({
          text: 'Loading'
        })
        this.$gsafety.startVoice(
          (res) => {
            that.audios.push(res)
            that.$vux.loading.hide()
          },
          // 取消
          () => {
            that.$vux.loading.hide()
          }
        )
      },
      deleteAudio(index) { // 删除视频自定义回调事件
        this.audios.splice(index, 1)
      },
      chooseVideo() {  // 点击录制视频
        const that = this
        that.$vux.loading.show({
          text: 'Loading'
        })
        this.$gsafety.startVideo(
          (res) => {
            that.videos.push(res)
            that.$vux.loading.hide()
          },
          // 取消
          () => {
            that.$vux.loading.hide()
          }
        )
      },
      deleteVideo(index) { // 删除视频自定义回调事件
        this.videos.splice(index, 1)
      },
      // 上报
      reportEvent() {
        console.log('reportEvent')
        const that = this
        Array.from(this.address, (x) => {
          if (x.name === this.addressArr[0]) {
            that.data.distCode = x.code
          }
          return false
        })

        Array.from(this.level, (x) => {
          if (x.name === this.levelArr[0]) {
            that.data.eventLevelCode = x.code
          }
          return false
        })
        that.data.attachId = this.serverIds
        const data = that.data
        this.validation(data)
        const URL = `${siteUrl}/eventInfo/sendsave`
        console.log(data)
        this.$vux.confirm.show({
          title: '确认上报？',
          content: '',
          onConfirm() {
            that.$http.post(URL, data).then((response) => {
              console.log(response)
              console.log(response.body.response)
              // that.$router.push(`/report/addInfoTarget/${response.body.response.eventInfoId}`)
              const url = `${siteUrl}/eventInfo/sendInfoApply`
              that.data.mainObjectId = response.body.response
              that.$http.post(url, that.data).then((res) => {
                console.log(res)
                if (res.status === 200) {
                  // that.alertShow('上报成功')
                  that.$vux.toast.text('上报成功', 'middle')
                  that.$router.go(-1)
                }
              }, () => {
                that.$vux.confirm.hide()
                // that.alertShow('操作失败')
                that.$vux.toast.text('操作失败', 'middle')
              })
            }, () => {
              // that.alertShow('操作失败')
              that.$vux.toast.text('操作失败', 'middle')
              that.$vux.confirm.hide()
            })
          }
        })
      }
    }
  }
</script>
