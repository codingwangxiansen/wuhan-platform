<template>
  <div class="statis">
    <group title="统计汇总分类">
      <cell v-for="(item,index) in dataTime" :key="index" :title="item" @click.native="goInfo(index)"></cell>
    </group>
  </div>
</template>
<style type="less" scoped>
  .weui-cell:before {
    right: 15px;
  }
</style>
<script>
  import { Group, Cell } from 'vux'
  import Vue from 'vue'
  import VueResource from 'vue-resource'

  Vue.use(VueResource)


  export default {
    props: [],
    // 组件
    components: {
      Group,
      Cell
    },
    // 数据模型
    data() {
      return {
        dataTime: ['季报', '月报', '周报']
      }
    },
    created() {
    },
    // 方法
    methods: {
      goInfo(id) {
        const r = `/statisbtn/info/${id}`
        this.$router.push(r)
      }
    }
  }
</script>
