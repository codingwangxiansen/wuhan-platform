/**
 * Created by wjf on 2018/1/31.
 */
const config = {
  // 服务端root
  serverUrl: '/geminirest',
  // 后台服务root
  siteUrl: '/geminirest/api/m',
  // 前端服务root
  htmlUrl: '/geminihtml',
  // 文件服务名
  fileServer: '/geminifs',
  // 附件页面
  attach_view: `${this.htmlUrl}/module/attach.html`,
  // 地图的key
  mapKey: '8a7b9aac0db21f9dd995e61a14685f05'
}

export default config
