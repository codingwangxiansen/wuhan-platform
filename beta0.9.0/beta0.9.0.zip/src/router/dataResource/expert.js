/**
 * Created by 123 on 2018/3/14.
 * 专家模块路由
 */

const Expert = () => import('components/demo/Demo')

const expert = [{
  path: '/Expert',
  name: 'Demo',
  component: Expert
}]

export default expert
