/**
 * Created by wangjunfei on 2018/1/6.
 */
import Vue from 'vue'
import VueRouter from 'vue-router'

// 404页面
import NotFoundComponent from 'components/mycomponents/NotFoundComponent'

// 首页
// import Index from 'components/inforeport/Index'

import register from './register' // 用户注册模块
import user from './user' // 用户管理模块
import push from './push' // 消息中心模块
import demo from './demo' // 测试用

import report from './eventInfo/report' // 信息接报--上报模块
import check from './eventInfo/check' // 信息接报--审核模块
import deal from './eventInfo/deal' // 信息接报--办理模块
import instruction from './eventInfo/instruction' // 信息接报--批示模块
import statistics from './eventInfo/statistics' // 信息接报--批示模块
// 启用路由
Vue.use(VueRouter)

// 定义一个能够被 Webpack 自动代码分割的异步组件
const Index = () => import('components/inforeport/Index')
const LeaderSelectorPage = () => import('components/gsafetycomponents/LeaderSelectorPage')
const EventTypeSelector = () => import('components/gsafetycomponents/EventTypeSelector')
const DistrictSelector = () => import('components/gsafetycomponents/DistrictSelector')
const ErrorView = () => import('components/gsafetycomponents/ErrorView')
/* 首页 */
const index = [
  {
    path: '*', // 404页面
    component: NotFoundComponent
  }, {
    path: '/', // 首页
    component: Index
  }, {
    path: '/leaderSelect', // 选择领导页面
    name: 'LeaderSelect',
    component: LeaderSelectorPage
  }, {
    path: '/eventTypeSelect', // 选择事件类型页面
    name: 'eventTypeSelect',
    component: EventTypeSelector
  }, {
    path: '/districtSelector', // 选择地区页面
    name: 'districtSelector',
    component: DistrictSelector
  }, {
    path: '/error', // 跳转路由报错页面
    name: 'ErrorView',
    component: ErrorView
  }]

const routers = index.concat(register, user, push, report, check, deal,
                            instruction, statistics, demo)

const router = new VueRouter({
  routes: routers
})

export default router
