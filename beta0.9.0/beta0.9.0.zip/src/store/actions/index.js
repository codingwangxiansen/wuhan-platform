/**
 * Created by wangjunfei on 2018/1/10.
 */
// Action 提交的是 mutation，而不是直接变更状态。
// Action 可以包含任意异步操作。

import axios from 'axios'
import config from '../../config'


function getEventType(cb) { // 从服务端请求获取事件类型
  axios.get(`${config.siteUrl}/eventInfo/list/eventTypeList`).then((res) => {
    if (res.data && res.data.response) {
      if (typeof cb === 'function') {
        cb(JSON.parse(res.data.response))
      }
    }
  })
}

function setUser(cb) { // 从服务端请求获取当前用户
  axios.post(`${config.siteUrl}/basedata/user/getUser`).then((res) => {
    if (res.data && res.data.response) {
      if (typeof cb === 'function') {
        cb(res.data.response)
      }
    }
  })
}

function setAllUser(cb) { // 从服务端请求获取当前用户
  axios.get(`${config.siteUrl}/basedata/user/findAllUser`).then((res) => {
    if (res.data && res.data.response) {
      if (typeof cb === 'function') {
        cb(res.data.response)
      }
    }
  })
}

function setGroupLeader(cb) { // 从服务端请求获取当前用户
  axios.get(`${config.siteUrl}/eventInfo/get-leader?leaderType=1`).then((res) => {
    if (res.data && res.data.response) {
      if (typeof cb === 'function') {
        cb(res.data.response)
      }
    }
  })
}

function setCityLeader(cb) { // 从服务端请求获取当前用户
  axios.get(`${config.siteUrl}/eventInfo/get-leader?leaderType=2`).then((res) => {
    if (res.data && res.data.response) {
      if (typeof cb === 'function') {
        cb(res.data.response)
      }
    }
  })
}

export default {
  setUser({ commit }) {
    setUser((res) => {
      commit('setUser', res)
    })
  },
  setAllUser({ commit }) {
    setAllUser((res) => {
      commit('setAllUser', res)
    })
  },
  setGroupLeader({ commit }) {
    setGroupLeader((res) => {
      commit('setGroupLeader', res)
    })
  },
  setCityLeader({ commit }) {
    setCityLeader((res) => {
      commit('setCityLeader', res)
    })
  },
  updateEventType({ commit }) { // 修改事件类型
    getEventType((res) => {
      commit('updateEventType', res)
    })
  },
  showPageLoading({ commit }) {
    commit('showPageLoading')
  },
  hidePageLoading({ commit }) {
    commit('hidePageLoading')
  },
  initChart({ state, commit }) {
    return new Promise((resolve) => {
      setTimeout(() => {
        if (!state.echarts) {
          const echarts = require('echarts')
          commit('initECharts', echarts)
        }
        resolve(state.echarts)
      }, 50)
    })
  }
}
