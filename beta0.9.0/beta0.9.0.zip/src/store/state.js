/**
 * Created by wangjunfei on 2018/1/10.
 */
/* 内存状态数据 */
export default {
  // 查看图片时滚动的高度
  scrollTop: 0,
  projectType: 'app', // 当前项目的类型 app--安卓应用  mini--小程序
  user: {}, // 用户信息
  isRefresh: true, // 跳转到新路由是否刷新页面，页面状态控制
  allowBack: true, // 控制页面是否回退
  gisLocation: { // 地理位置信息
    x: 114.296350, // 经度
    y: 30.595510, // 纬度
    searchExtent: [110.58838, 29.25286, 118.09204, 31.98012], // 搜索范围
    address: '',
    isEdit: true
  },
  // 办理页面当前弹出的窗口 默认没有弹出窗口 advise--拟办  trans--转办  check--审核
  dealWindow: '',
  leaderList: [], // 通用选择领导页面选中的领导ID数组
  imgSrc: [], // 设置图片路径
  headerShow: true,
  eventType: [], // 事件类型
  groupLeader: [],
  cityLeader: [],
  pageLoading: {
    isShowLoading: false,
    percent: 0
  },
  echarts: '', // echarts图表对象
  headerOption: { // 公共的头部的配置
    showHeader: true,
    headerRightIcon: '',
    leftOptions: {
      showBack: false,
      backText: '',
      preventGoBack: true
    },
    title: '武汉市应急值守平台',
    transition: '',
    rightOptions: {
      showMore: false
    }
  },
  popupArgsList: [], // 当前页弹窗参数列表
  chooseEventType: {} // 选中的事件类型
}
