/**
 * Created by 123 on 2018/3/22.
 * 调用安卓应用的方法
 */
/* global COMM_APP */

// 安卓端自带COMM_APP全局变量
const APPSDK = (function () {
  const noticeFn = () => {
    if (typeof COMM_APP === 'undefined') {
      console.warn('请在GsafetyApp中调用接口')
      return false
    }
    return true
  }
  return {
    // 选择一个图片
    chooseImage(data, callback) {
      const fn = noticeFn()
      if (!fn) {
        return
      }
      COMM_APP.chooseImageCallback = (res) => {
        const obj = JSON.parse(res)
        callback(obj)
      }
      COMM_APP.chooseImage(JSON.stringify(data))
    },
    // 上传一个文件
    uploadImage(data, callback) {
      const fn = noticeFn()
      if (!fn) {
        return
      }
      COMM_APP.uploadImageCallback = (res) => {
        const obj = JSON.parse(res)
        callback(obj)
      }
      COMM_APP.uploadImage(JSON.stringify(data))
    },

    // 写入缓存
    writeCache(data, callback) {
      const fn = noticeFn()
      if (!fn) {
        return
      }
      COMM_APP.writeCacheCallback = (res) => {
        const obj = JSON.parse(res)
        callback(obj)
      }
      COMM_APP.writeCache(JSON.stringify(data))
    },
    // 读取缓存
    readCache(data, callback) {
      const fn = noticeFn()
      if (!fn) {
        return
      }
      COMM_APP.readCacheCallback = (res) => {
        const obj = JSON.parse(res)
        callback(obj)
      }
      COMM_APP.readCache(JSON.stringify(data))
    },
    // 设置页面头部右上角的按钮显示以及图标(响应事件调用onMenuClick事件)
    setTitleBar(data) {
      const fn = noticeFn()
      if (!fn) {
        console.warn('setTitleBar data:')
        console.warn(data)
        return
      }
      COMM_APP.setTitleBar(JSON.stringify(data))
    },
    // 打开 intent
    openIntent(intent, data) {
      const fn = noticeFn()
      if (!fn) {
        return
      }
      COMM_APP.openIntent(intent, JSON.stringify(data))
    },
    // 打开链接
    openWindow(data) {
      const fn = noticeFn()
      if (!fn) {
        location.href = data.url
        return
      }
      if (!data.actionBarType) {
        data.actionBarType = 1
      }
      COMM_APP.openWindow(JSON.stringify(data))
    },
    /**
     * 关闭当前activity
     */
    closeWindow(data) {
      let optStr = '{}'
      if (data) {
        optStr = JSON.stringify(data)
      } else {
        console.log(`close window with ${data}`)
      }
      const fn = noticeFn()
      if (!fn) {
        console.log(`please close activity in app, callback data:${optStr}`)
        history.go(-1)// 后退到上一个页面
        return
      }
      if (data) {
        COMM_APP.closeWindow(optStr)
      } else {
        COMM_APP.closeWindow() // 无参时写法
      }
    },
    // 更新设置
    updateSettings(data, callback) {
      const fn = noticeFn()
      if (!fn) {
        return
      }
      COMM_APP.updateSettingsCallback = (res) => {
        const obj = JSON.parse(res)
        callback(obj)
      }
      COMM_APP.updateSettings(JSON.stringify(data))
    },
    // 加载设置
    loadSettings(data, callback) {
      const fn = noticeFn()
      if (!fn) {
        return
      }
      COMM_APP.loadSettingsCallback = (res) => {
        callback(JSON.parse(res))
      }
      COMM_APP.loadSettings(data)
    },
    // 底部弹窗
    onMenuClick(callback) {
      const fn = noticeFn()
      if (!fn) {
        return
      }
      COMM_APP.onMenuClick = () => {
        callback()
      }
    },
    // 页面返回刷新
    translateDataCallback(callback) {
      const fn = noticeFn()
      if (!fn) {
        console.info(`bind COMM_APP translateDataCallback : ${callback}`)
        return
      }
      COMM_APP.translateDataCallback = (res) => {
        callback(res)
      }
    },
    openSession(team) {
      const fn = noticeFn()
      if (!fn) {
        console.info(`start COMM_APP openSession : ${team}`)
        return
      }
      COMM_APP.openSession(team)
    },
    // 底部弹窗
    setTitle(title) {
      const fn = noticeFn()
      if (!fn) {
        return
      }
      COMM_APP.setTitle(title)
    },
    // 调起第三方导航功能
    startNavigate(data) {
      const fn = noticeFn()
      if (!fn) {
        console.debug('开启导航')
        return
      }
      COMM_APP.startNav(JSON.stringify(data))
    },
    // 自动聚焦时调起软键盘，若为开启状态则关闭
    showOrHideSoftInput() {
      const fn = noticeFn()
      if (!fn) {
        return
      }
      COMM_APP.showOrHideSoftInput()
    },

    // 自动聚焦时调起软键盘，若为开启状态则关闭
    weixinFriends(data) {
      const fn = noticeFn()
      if (!fn) {
        console.debug('weixinFriends')
        console.debug(data)
        return
      }
      COMM_APP.shareToWeiXin(JSON.stringify(data))
    },
    // 录制视频
    startVideo(callback, cancel) {
      const fn = noticeFn()
      if (!fn) {
        // 如果是在应用外，模拟一个假的请求返回
        // const mockStartVideo = { id: '1', attachPath: '/dummy/test.mp4' }
        // callback(mockStartVideo)
        cancel()
        return
      }
      // 视频上传
      COMM_APP.startVideoCallback = (res) => {
        if (res.errcode) {
          console.error(res)
          cancel(res)
          return
        }
        callback(res)
        alert('视频上传成功！')
      }
      const data = {}
      COMM_APP.startVideo(JSON.stringify(data))
    },
    // 播放视频
    playVideo(data) {
      const fn = noticeFn()
      if (!fn) {
        console.debug('playVideo')
        console.debug(data)
        return
      }
      COMM_APP.playVideo(JSON.stringify(data))
    },
    // 发送短信
    sms(data) {
      const fn = noticeFn()
      if (!fn) {
        console.debug('sms')
        console.debug(data)
        return
      }
      COMM_APP.sendMsg(JSON.stringify(data))
    },
    // 录制音频
    startVoice(callback, cancel) {
      const fn = noticeFn()
      if (!fn) {
        // 如果时在应用外，模拟一个假的请求返回
        cancel()
        return
      }
      COMM_APP.startVoiceCallback = function (res) {
        if (res.errcode) {
          console.error(res)
          cancel()
          alert('上传失败！')
          return
        }
        callback(res)
        alert('上传成功！')
      }
      // 音频上传点击返回时触发
      COMM_APP.cancelVoiceCallback = function (res) {
        cancel(res)
      }
      const data = {}
      COMM_APP.startVoice(JSON.stringify(data))
    },
    // 播放音频
    playVoice(data) {
      const fn = noticeFn()
      if (!fn) {
        console.debug('playVoice')
        console.debug(data)
        return
      }
      COMM_APP.playVoice(JSON.stringify(data))
    }
  }
}())

export default APPSDK
